"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Stars, Sparkles, MeshDistortMaterial } from "@react-three/drei";
import * as THREE from "three";

function CoreOrb() {
  return (
    <Float speed={1.6} rotationIntensity={0.6} floatIntensity={1.4}>
      <mesh>
        <sphereGeometry args={[2.3, 64, 64]} />
        <MeshDistortMaterial
          color="#7c3aed"
          metalness={0.85}
          roughness={0.18}
          distort={0.42}
          speed={2.2}
        />
      </mesh>
    </Float>
  );
}

function Ring({ radius, color, tilt, speed }: { radius: number; color: string; tilt: number; speed: number }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (ref.current) {
      ref.current.rotation.z += delta * speed;
      ref.current.rotation.x = tilt;
    }
  });
  return (
    <mesh ref={ref}>
      <torusGeometry args={[radius, 0.035, 16, 128]} />
      <meshBasicMaterial color={color} transparent opacity={0.7} />
    </mesh>
  );
}

function Shape({
  position,
  color,
  emissive,
  kind,
}: {
  position: [number, number, number];
  color: string;
  emissive: string;
  kind: "ico" | "octa" | "knot" | "dodeca";
}) {
  return (
    <Float speed={2.2} rotationIntensity={1.6} floatIntensity={2.4}>
      <mesh position={position}>
        {kind === "ico" && <icosahedronGeometry args={[0.55, 0]} />}
        {kind === "octa" && <octahedronGeometry args={[0.6, 0]} />}
        {kind === "knot" && <torusKnotGeometry args={[0.35, 0.12, 128, 16]} />}
        {kind === "dodeca" && <dodecahedronGeometry args={[0.5, 0]} />}
        <meshStandardMaterial
          color={color}
          emissive={emissive}
          emissiveIntensity={0.55}
          metalness={0.9}
          roughness={0.2}
        />
      </mesh>
    </Float>
  );
}

function Rig({ children }: { children: React.ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state, delta) => {
    if (!ref.current) return;
    const targetX = state.pointer.y * 0.18;
    const targetY = state.pointer.x * 0.28;
    ref.current.rotation.x = THREE.MathUtils.damp(ref.current.rotation.x, targetX, 2.5, delta);
    ref.current.rotation.y = THREE.MathUtils.damp(ref.current.rotation.y, targetY, 2.5, delta);
  });
  return <group ref={ref}>{children}</group>;
}

export default function HeroScene() {
  return (
    <Canvas
      camera={{ position: [0, 0, 9.5], fov: 46 }}
      dpr={[1, 1.8]}
      gl={{ antialias: true, alpha: true }}
      className="!absolute inset-0"
    >
      <Suspense fallback={null}>
        <fog attach="fog" args={["#05050d", 11, 26]} />
        <ambientLight intensity={0.55} />
        <directionalLight position={[6, 8, 5]} intensity={2.2} color="#ffffff" />
        <directionalLight position={[-7, -3, -4]} intensity={1.1} color="#8b5cf6" />
        <directionalLight position={[0, -6, 4]} intensity={0.7} color="#22d3ee" />

        <Stars radius={70} depth={45} count={2800} factor={3.2} saturation={0.6} fade speed={0.8} />
        <Sparkles count={110} scale={13} size={2.4} speed={0.35} color="#67e8f9" opacity={0.7} />
        <Sparkles count={70} scale={10} size={3} speed={0.25} color="#e879f9" opacity={0.55} />

        <Rig>
          <CoreOrb />
          <Ring radius={3.4} color="#8b5cf6" tilt={Math.PI / 2.15} speed={0.25} />
          <Ring radius={4.3} color="#22d3ee" tilt={Math.PI / 2.6} speed={-0.18} />
          <Ring radius={5.4} color="#e879f9" tilt={Math.PI / 1.9} speed={0.12} />
          <Shape position={[-4.4, 1.8, -1]} color="#22d3ee" emissive="#0e7490" kind="ico" />
          <Shape position={[4.6, -1.6, -0.5]} color="#e879f9" emissive="#a21caf" kind="octa" />
          <Shape position={[3.8, 2.4, -2]} color="#f59e0b" emissive="#b45309" kind="knot" />
          <Shape position={[-4.2, -2.4, -1.5]} color="#34d399" emissive="#047857" kind="dodeca" />
          <Shape position={[0, 3.6, -3]} color="#818cf8" emissive="#4338ca" kind="ico" />
          <Shape position={[0.8, -3.8, -2.5]} color="#f472b6" emissive="#be185d" kind="knot" />
        </Rig>
      </Suspense>
    </Canvas>
  );
}
