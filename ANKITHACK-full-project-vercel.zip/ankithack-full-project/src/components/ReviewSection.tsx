"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MessageSquare, Loader2, CheckCircle2, User } from "lucide-react";
import { StarsDisplay, StarsInput } from "@/components/StarRating";
import Reveal from "@/components/Reveal";

type Review = {
  id: number;
  authorName: string;
  rating: number;
  comment: string;
  createdAt: string | Date;
};

export default function ReviewSection({
  appId,
  reviews,
}: {
  appId: number;
  reviews: Review[];
}) {
  const router = useRouter();
  const [form, setForm] = useState({ authorName: "", rating: 5, comment: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "done">("idle");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.authorName.trim()) return;
    setStatus("sending");
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appId, ...form }),
      });
      if (!res.ok) throw new Error();
      setStatus("done");
      setForm({ authorName: "", rating: 5, comment: "" });
      router.refresh();
      setTimeout(() => setStatus("idle"), 3000);
    } catch {
      setStatus("idle");
    }
  }

  return (
    <div className="grid gap-10 lg:grid-cols-2">
      {/* reviews list */}
      <div>
        <h3 className="flex items-center gap-2 font-display text-2xl font-bold text-white">
          <MessageSquare size={20} className="text-cyan-400" />
          User Reviews
          <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-xs font-semibold text-zinc-400">
            {reviews.length}
          </span>
        </h3>

        <div className="mt-6 space-y-4">
          {reviews.length === 0 && (
            <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center text-sm text-zinc-500">
              Abhi koi review nahi — pehla review aap likho!
            </div>
          )}
          {reviews.map((r, i) => (
            <Reveal key={r.id} delay={i * 0.05}>
              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-violet-600 to-cyan-500 text-white">
                      <User size={16} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{r.authorName}</p>
                      <p className="text-[11px] text-zinc-500">
                        {new Date(r.createdAt).toLocaleDateString("en-IN", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                  </div>
                  <StarsDisplay value={r.rating} />
                </div>
                {r.comment && (
                  <p className="mt-3 text-sm leading-relaxed text-zinc-400">{r.comment}</p>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* review form */}
      <div>
        <div className="gradient-border rounded-3xl p-7">
          <h3 className="font-display text-xl font-bold text-white">Rating do</h3>
          <p className="mt-1 text-sm text-zinc-500">Aapka feedback apps ko behtar banata hai.</p>

          <form onSubmit={submit} className="mt-6 space-y-5">
            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-zinc-500">
                Aapka naam
              </label>
              <input
                value={form.authorName}
                onChange={(e) => setForm({ ...form, authorName: e.target.value })}
                required
                placeholder="e.g. Rahul"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition-all focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/20"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-zinc-500">
                Rating
              </label>
              <StarsInput value={form.rating} onChange={(v) => setForm({ ...form, rating: v })} />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-zinc-500">
                Review (optional)
              </label>
              <textarea
                value={form.comment}
                onChange={(e) => setForm({ ...form, comment: e.target.value })}
                rows={3}
                placeholder="Kaisa laga app?"
                className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition-all focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/20"
              />
            </div>

            <button
              type="submit"
              disabled={status === "sending"}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-3.5 font-display text-sm font-bold text-white shadow-[0_0_28px_rgba(139,92,246,0.35)] transition-all hover:shadow-[0_0_40px_rgba(34,211,238,0.5)] disabled:opacity-60"
            >
              {status === "sending" ? (
                <Loader2 size={16} className="animate-spin" />
              ) : status === "done" ? (
                <CheckCircle2 size={16} />
              ) : null}
              {status === "done" ? "Review submitted!" : "Submit Review"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
