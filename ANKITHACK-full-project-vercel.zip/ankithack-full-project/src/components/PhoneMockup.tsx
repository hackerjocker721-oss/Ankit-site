"use client";

import { useRef, useState } from "react";
import { Star, Download } from "lucide-react";
import AppIcon from "@/components/AppIcon";

export default function PhoneMockup({
  name,
  category,
  iconUrl,
  rating,
  version,
}: {
  name: string;
  category: string;
  iconUrl?: string | null;
  rating: number;
  version: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [rot, setRot] = useState({ x: 0, y: 0 });

  function onMove(e: React.MouseEvent) {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setRot({ x: -py * 18, y: px * 24 });
  }

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setRot({ x: 0, y: 0 })}
      className="perspective-1200 flex items-center justify-center py-10"
    >
      <div
        className="preserve-3d relative w-64 rounded-[2.6rem] border border-white/15 bg-gradient-to-b from-zinc-800 to-zinc-900 p-2 shadow-[0_40px_90px_rgba(0,0,0,0.65)] transition-transform duration-200 ease-out"
        style={{ transform: `rotateX(${rot.x}deg) rotateY(${rot.y}deg)` }}
      >
        {/* glow behind phone */}
        <div className="absolute -inset-8 -z-10 rounded-[3.5rem] bg-gradient-to-b from-violet-600/30 to-cyan-500/25 blur-3xl" />

        {/* side buttons */}
        <div className="absolute -right-[2px] top-24 h-14 w-[3px] rounded-full bg-zinc-600" />
        <div className="absolute -left-[2px] top-20 h-8 w-[3px] rounded-full bg-zinc-600" />
        <div className="absolute -left-[2px] top-32 h-12 w-[3px] rounded-full bg-zinc-600" />

        {/* screen */}
        <div className="relative overflow-hidden rounded-[2.1rem] bg-[#0a0a16]">
          {/* notch */}
          <div className="absolute left-1/2 top-2 z-20 h-6 w-24 -translate-x-1/2 rounded-full bg-black" />

          {/* screen content */}
          <div className="relative flex min-h-[480px] flex-col items-center bg-gradient-to-b from-violet-950/60 via-[#0a0a16] to-cyan-950/40 px-5 pb-6 pt-14">
            <div className="animate-spin-slow absolute -top-20 h-56 w-56 rounded-full border border-dashed border-violet-500/20" />
            <div className="animate-spin-slow absolute -top-10 h-36 w-36 rounded-full border border-dashed border-cyan-500/20" />

            <div style={{ transform: "translateZ(50px)" }} className="flex flex-col items-center">
              <div className="animate-floaty">
                <AppIcon name={name} iconUrl={iconUrl} className="h-24 w-24 shadow-[0_0_50px_rgba(139,92,246,0.5)]" />
              </div>
              <h3 className="mt-5 font-display text-xl font-bold text-white">{name}</h3>
              <p className="mt-1 text-xs text-violet-300/80">{category} · v{version}</p>

              <div className="mt-3 flex items-center gap-1.5">
                <Star size={13} className="fill-amber-400 text-amber-400" />
                <span className="text-sm font-semibold text-white">
                  {rating > 0 ? rating.toFixed(1) : "New"}
                </span>
              </div>

              <button className="mt-5 flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-2.5 text-sm font-bold text-white shadow-[0_0_30px_rgba(139,92,246,0.5)]">
                <Download size={15} />
                Install
              </button>

              {/* fake UI rows */}
              <div className="mt-8 w-full space-y-2.5 opacity-70">
                {[82, 64, 74, 55].map((w, i) => (
                  <div
                    key={i}
                    className="h-8 rounded-lg border border-white/10 bg-white/5"
                    style={{ width: `${w}%`, marginLeft: i % 2 ? "auto" : 0 }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
