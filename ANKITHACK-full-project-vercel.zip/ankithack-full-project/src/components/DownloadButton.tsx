"use client";

import { useState } from "react";
import { Download, Loader2, CheckCircle2, ExternalLink } from "lucide-react";

export default function DownloadButton({
  appId,
  disabled,
}: {
  appId: number;
  disabled?: boolean;
}) {
  const [state, setState] = useState<"idle" | "loading" | "done">("idle");

  async function handle() {
    if (disabled || state !== "idle") return;
    setState("loading");
    try {
      const res = await fetch(`/api/apps/${appId}/download`, { method: "POST" });
      const data = await res.json();
      if (data.url) {
        window.open(data.url, "_blank");
      }
      setState("done");
      setTimeout(() => setState("idle"), 3500);
    } catch {
      setState("idle");
    }
  }

  return (
    <button
      onClick={handle}
      disabled={disabled}
      className="group relative flex items-center gap-2.5 overflow-hidden rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-500 px-8 py-4 font-display text-base font-bold text-white shadow-[0_0_40px_rgba(139,92,246,0.5)] transition-all hover:scale-[1.03] hover:shadow-[0_0_60px_rgba(34,211,238,0.6)] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:scale-100"
    >
      <span className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent" />
      {state === "loading" ? (
        <Loader2 size={19} className="animate-spin" />
      ) : state === "done" ? (
        <CheckCircle2 size={19} />
      ) : (
        <Download size={19} className="transition-transform group-hover:translate-y-0.5" />
      )}
      {disabled
        ? "Link coming soon"
        : state === "done"
          ? "Download started!"
          : "Download Now"}
      {!disabled && state === "idle" && <ExternalLink size={14} className="opacity-60" />}
    </button>
  );
}
