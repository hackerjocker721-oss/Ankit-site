import Link from "next/link";
import { Globe, Mail, MessageCircle, Heart } from "lucide-react";
import ContactForm from "@/components/ContactForm";

export default function Footer({ logo, title }: { logo: string; title: string }) {
  return (
    <footer id="contact" className="relative overflow-hidden border-t border-white/10">
      <div className="orb -top-40 left-1/4 h-96 w-96 bg-violet-700/25" />
      <div className="orb -bottom-40 right-1/4 h-96 w-96 bg-cyan-600/20" />

      <div className="relative mx-auto max-w-7xl px-5 py-16 md:px-8">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <div className="flex items-center gap-3">
              <img src={logo} alt={title} className="h-12 w-12 rounded-2xl border border-white/15" />
              <div>
                <p className="font-display text-2xl font-bold text-white">
                  {title}<span className="text-cyan-400">.</span>
                </p>
                <p className="text-sm text-zinc-500">Apps that feel alive.</p>
              </div>
            </div>
            <p className="mt-5 max-w-md leading-relaxed text-zinc-400">
              Ek developer ki zid se bani app universe — har app handcrafted, har detail
              obsessive. Download karo, experience karo, aur feedback do.
            </p>
            <div className="mt-6 flex gap-3">
              {[Globe, Mail, MessageCircle].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="rounded-xl border border-white/10 bg-white/5 p-3 text-zinc-400 transition-all hover:-translate-y-1 hover:border-violet-400/50 hover:text-white hover:shadow-[0_0_24px_rgba(139,92,246,0.4)]"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div className="grid gap-8 sm:grid-cols-2">
            <div>
              <p className="font-display text-sm font-semibold uppercase tracking-widest text-zinc-500">
                Explore
              </p>
              <ul className="mt-4 space-y-3 text-sm">
                <li><Link href="/" className="text-zinc-400 transition-colors hover:text-cyan-400">Home</Link></li>
                <li><Link href="/apps" className="text-zinc-400 transition-colors hover:text-cyan-400">App Library</Link></li>
                <li><Link href="/admin" className="text-zinc-400 transition-colors hover:text-cyan-400">Admin Panel</Link></li>
              </ul>
            </div>
            <ContactForm />
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 text-sm text-zinc-500 sm:flex-row">
          <p>© {new Date().getFullYear()} {title}. All rights reserved.</p>
          <p className="flex items-center gap-1.5">
            Crafted with <Heart size={14} className="fill-fuchsia-500 text-fuchsia-500" /> by {title}
          </p>
        </div>
      </div>
    </footer>
  );
}
