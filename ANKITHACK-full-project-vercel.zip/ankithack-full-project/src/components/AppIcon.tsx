export default function AppIcon({
  name,
  iconUrl,
  className = "h-16 w-16",
}: {
  name: string;
  iconUrl?: string | null;
  className?: string;
}) {
  if (iconUrl) {
    return (
      <img
        src={iconUrl}
        alt={name}
        className={`${className} rounded-2xl border border-white/15 object-cover shadow-lg`}
      />
    );
  }
  const letter = name?.charAt(0)?.toUpperCase() || "A";
  return (
    <div
      className={`${className} flex items-center justify-center rounded-2xl border border-white/15 bg-gradient-to-br from-violet-600 via-fuchsia-600 to-cyan-500 font-display text-2xl font-bold text-white shadow-lg`}
    >
      {letter}
    </div>
  );
}
