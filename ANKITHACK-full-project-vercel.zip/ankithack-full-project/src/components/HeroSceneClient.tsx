"use client";

import dynamic from "next/dynamic";

const HeroScene = dynamic(() => import("@/components/HeroScene"), {
  ssr: false,
  loading: () => (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="h-40 w-40 animate-pulse-glow rounded-full bg-violet-600/30 blur-3xl" />
    </div>
  ),
});

export default function HeroSceneClient() {
  return <HeroScene />;
}
