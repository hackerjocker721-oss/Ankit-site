import Link from "next/link";
import { Download, Star, ChevronRight } from "lucide-react";
import TiltCard from "@/components/TiltCard";
import AppIcon from "@/components/AppIcon";

export type AppCardData = {
  id: number;
  name: string;
  slug: string;
  tagline: string;
  category: string;
  iconUrl: string | null;
  downloads: number;
  ratingAvg: number;
  ratingCount: number;
  featured: boolean;
};

export default function AppCard({ app, index = 0 }: { app: AppCardData; index?: number }) {
  return (
    <TiltCard className="h-full">
      <Link
        href={`/apps/${app.slug}`}
        className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-white/[0.02] p-5 transition-colors duration-300 hover:border-violet-400/40"
      >
        <div className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-violet-600/20 blur-3xl transition-all duration-500 group-hover:bg-cyan-500/25" />

        {app.featured && (
          <span className="absolute right-4 top-4 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-black">
            Featured
          </span>
        )}

        <div style={{ transform: "translateZ(40px)" }} className="flex items-start gap-4">
          <AppIcon name={app.name} iconUrl={app.iconUrl} className="h-16 w-16 shrink-0" />
          <div className="min-w-0">
            <h3 className="truncate font-display text-lg font-bold text-white transition-colors group-hover:text-cyan-300">
              {app.name}
            </h3>
            <p className="text-xs font-medium text-violet-300/80">{app.category}</p>
          </div>
        </div>

        <p className="mt-4 line-clamp-2 text-sm leading-relaxed text-zinc-400">
          {app.tagline || "A handcrafted experience."}
        </p>

        <div className="mt-auto flex items-center justify-between pt-5">
          <div className="flex items-center gap-4 text-xs text-zinc-500">
            <span className="flex items-center gap-1">
              <Star size={13} className="fill-amber-400 text-amber-400" />
              <span className="font-semibold text-zinc-300">{app.ratingAvg > 0 ? app.ratingAvg.toFixed(1) : "New"}</span>
            </span>
            <span className="flex items-center gap-1">
              <Download size={13} />
              {app.downloads >= 1000
                ? `${(app.downloads / 1000).toFixed(1)}k`
                : app.downloads}
            </span>
          </div>
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-zinc-400 transition-all duration-300 group-hover:border-cyan-400/50 group-hover:bg-cyan-400/10 group-hover:text-cyan-300">
            <ChevronRight size={16} />
          </span>
        </div>
      </Link>
    </TiltCard>
  );
}
