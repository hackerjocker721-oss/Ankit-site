"use client";

import { useState } from "react";
import { Loader2, Upload, X, Star, Check } from "lucide-react";
import AppIcon from "@/components/AppIcon";
import { CATEGORIES } from "@/lib/constants";

export type AppRow = {
  id: number;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  features: string;
  category: string;
  version: string;
  size: string;
  iconUrl: string | null;
  bannerUrl: string | null;
  downloadUrl: string | null;
  downloads: number;
  ratingAvg: number;
  ratingCount: number;
  featured: boolean;
  published: boolean;
};

async function uploadFile(file: File, kind: string): Promise<string> {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("kind", kind);
  const res = await fetch("/api/upload", { method: "POST", body: fd });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Upload failed");
  return data.url as string;
}

export default function AppForm({
  app,
  onClose,
  onSaved,
}: {
  app: AppRow | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    name: app?.name || "",
    tagline: app?.tagline || "",
    category: app?.category || "Other",
    version: app?.version || "1.0.0",
    size: app?.size || "10 MB",
    description: app?.description || "",
    features: app?.features || "",
    iconUrl: app?.iconUrl || "",
    bannerUrl: app?.bannerUrl || "",
    downloadUrl: app?.downloadUrl || "",
    featured: app?.featured || false,
    published: app?.published !== false,
  });
  const [shots, setShots] = useState<string[]>([]);
  const [busy, setBusy] = useState<string>("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  async function handleUpload(
    e: React.ChangeEvent<HTMLInputElement>,
    kind: string,
    multiple = false
  ) {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setError("");
    setBusy(kind);
    try {
      if (multiple) {
        const urls: string[] = [];
        for (const f of Array.from(files)) {
          urls.push(await uploadFile(f, kind));
        }
        setShots((prev) => [...prev, ...urls]);
      } else {
        const url = await uploadFile(files[0], kind);
        if (kind === "apk") {
          setForm((f) => ({ ...f, downloadUrl: url }));
        } else {
          setForm((f) => ({ ...f, [`${kind}Url`]: url }));
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy("");
      e.target.value = "";
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setBusy("submit");
    setError("");
    try {
      const payload = { ...form, screenshots: shots };
      const res = await fetch(app ? `/api/apps/${app.id}` : "/api/apps", {
        method: app ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Save failed");
      setSaved(true);
      setTimeout(() => onSaved(), 700);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Save failed");
      setBusy("");
    }
  }

  const inputCls =
    "w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 outline-none transition-all focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/20";
  const labelCls = "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-zinc-500";

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="glass-strong relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-3xl p-8">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 rounded-full border border-white/10 bg-white/5 p-2 text-zinc-400 hover:text-white"
        >
          <X size={16} />
        </button>

        <h2 className="font-display text-2xl font-bold text-white">
          {app ? "Edit App" : "Upload New App"}
        </h2>
        <p className="mt-1 text-sm text-zinc-500">
          {app ? `Editing "${app.name}"` : "Nayi app ki details bharo aur publish karo."}
        </p>

        {saved && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
            <Check size={16} /> Saved successfully!
          </div>
        )}
        {error && (
          <div className="mt-4 rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={submit} className="mt-6 space-y-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className={labelCls}>App Name *</label>
              <input
                className={inputCls}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. NeonBeat"
                required
              />
            </div>
            <div>
              <label className={labelCls}>Category</label>
              <select
                className={inputCls}
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-zinc-900">
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className={labelCls}>Tagline (short description)</label>
            <input
              className={inputCls}
              value={form.tagline}
              onChange={(e) => setForm({ ...form, tagline: e.target.value })}
              placeholder="e.g. Music player with 3D visualizer"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className={labelCls}>Version</label>
              <input
                className={inputCls}
                value={form.version}
                onChange={(e) => setForm({ ...form, version: e.target.value })}
                placeholder="1.0.0"
              />
            </div>
            <div>
              <label className={labelCls}>Size</label>
              <input
                className={inputCls}
                value={form.size}
                onChange={(e) => setForm({ ...form, size: e.target.value })}
                placeholder="e.g. 18 MB"
              />
            </div>
          </div>

          <div>
            <label className={labelCls}>Full Description</label>
            <textarea
              className={`${inputCls} min-h-[100px] resize-y`}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="App ke baare mein detail mein likho..."
            />
          </div>

          <div>
            <label className={labelCls}>Features (one per line)</label>
            <textarea
              className={`${inputCls} min-h-[100px] resize-y`}
              value={form.features}
              onChange={(e) => setForm({ ...form, features: e.target.value })}
              placeholder={"Dark mode support\nOffline usage\nCloud sync"}
            />
          </div>

          {/* icon + banner uploads */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className={labelCls}>App Icon (image)</label>
              <div className="flex items-center gap-3">
                {form.iconUrl ? (
                  <AppIcon name={form.name || "A"} iconUrl={form.iconUrl} className="h-14 w-14" />
                ) : (
                  <AppIcon name={form.name || "A"} className="h-14 w-14" />
                )}
                <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-white/20 px-4 py-2.5 text-xs font-semibold text-zinc-400 transition-colors hover:border-violet-400/50 hover:text-white">
                  {busy === "icon" ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : (
                    <Upload size={14} />
                  )}
                  {form.iconUrl ? "Change icon" : "Upload icon"}
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleUpload(e, "icon")}
                  />
                </label>
              </div>
            </div>
            <div>
              <label className={labelCls}>Banner (optional)</label>
              <div className="flex items-center gap-3">
                {form.bannerUrl && (
                  <img src={form.bannerUrl} alt="banner" className="h-14 w-24 rounded-lg border border-white/15 object-cover" />
                )}
                <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-white/20 px-4 py-2.5 text-xs font-semibold text-zinc-400 transition-colors hover:border-violet-400/50 hover:text-white">
                  {busy === "banner" ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : (
                    <Upload size={14} />
                  )}
                  Upload banner
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleUpload(e, "banner")}
                  />
                </label>
              </div>
            </div>
          </div>

          {/* screenshots */}
          <div>
            <label className={labelCls}>Screenshots</label>
            <div className="flex flex-wrap items-center gap-3">
              {shots.map((s, i) => (
                <div key={i} className="group relative">
                  <img src={s} alt="" className="h-24 w-16 rounded-lg border border-white/15 object-cover" />
                  <button
                    type="button"
                    onClick={() => setShots(shots.filter((_, j) => j !== i))}
                    className="absolute -right-2 -top-2 rounded-full bg-rose-500 p-1 text-white opacity-0 transition-opacity group-hover:opacity-100"
                  >
                    <X size={10} />
                  </button>
                </div>
              ))}
              <label className="flex h-24 w-16 cursor-pointer items-center justify-center rounded-lg border border-dashed border-white/20 text-zinc-500 transition-colors hover:border-violet-400/50 hover:text-white">
                {busy === "screenshots" ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Upload size={16} />
                )}
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => handleUpload(e, "screenshots", true)}
                />
              </label>
            </div>
          </div>

          {/* download */}
          <div>
            <label className={labelCls}>Download Link (URL ya APK upload)</label>
            <div className="flex gap-2">
              <input
                className={inputCls}
                value={form.downloadUrl}
                onChange={(e) => setForm({ ...form, downloadUrl: e.target.value })}
                placeholder="https://... ya APK upload karo"
              />
              <label className="flex shrink-0 cursor-pointer items-center gap-2 rounded-xl border border-dashed border-white/20 px-4 text-xs font-semibold text-zinc-400 transition-colors hover:border-violet-400/50 hover:text-white">
                {busy === "apk" ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <Upload size={14} />
                )}
                APK
                <input
                  type="file"
                  accept=".apk,application/vnd.android.package-archive"
                  className="hidden"
                  onChange={(e) => handleUpload(e, "apk")}
                />
              </label>
            </div>
          </div>

          <div className="flex flex-wrap gap-6">
            <label className="flex cursor-pointer items-center gap-2.5 text-sm text-zinc-300">
              <input
                type="checkbox"
                checked={form.featured}
                onChange={(e) => setForm({ ...form, featured: e.target.checked })}
                className="h-4 w-4 accent-violet-500"
              />
              <Star size={14} className="text-amber-400" /> Featured on home
            </label>
            <label className="flex cursor-pointer items-center gap-2.5 text-sm text-zinc-300">
              <input
                type="checkbox"
                checked={form.published}
                onChange={(e) => setForm({ ...form, published: e.target.checked })}
                className="h-4 w-4 accent-violet-500"
              />
              Published (visible publicly)
            </label>
          </div>

          <button
            type="submit"
            disabled={busy === "submit"}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-3.5 font-display font-bold text-white shadow-[0_0_28px_rgba(139,92,246,0.35)] transition-all hover:shadow-[0_0_40px_rgba(34,211,238,0.5)] disabled:opacity-60"
          >
            {busy === "submit" && <Loader2 size={16} className="animate-spin" />}
            {app ? "Update App" : "Publish App"}
          </button>
        </form>
      </div>
    </div>
  );
}
