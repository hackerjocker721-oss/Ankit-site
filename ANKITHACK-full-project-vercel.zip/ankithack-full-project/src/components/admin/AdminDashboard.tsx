"use client";

import { useCallback, useEffect, useState } from "react";
import {
  LayoutDashboard,
  AppWindow,
  Settings,
  Inbox,
  LogOut,
  Loader2,
  Lock,
  Eye,
  EyeOff,
  Trash2,
  Pencil,
  Plus,
  Star,
  Download,
  MessageSquare,
  RefreshCw,
  Upload,
} from "lucide-react";
import AppForm, { type AppRow } from "@/components/admin/AppForm";
import AppIcon from "@/components/AppIcon";

type Message = {
  id: number;
  name: string;
  email: string;
  message: string;
  read: boolean;
  createdAt: string;
};

type Stats = {
  appCount: number;
  totalDownloads: number;
  reviewCount: number;
  messageCount: number;
  avgRating: number;
};

type Tab = "overview" | "apps" | "settings" | "messages";

export default function AdminDashboard() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [apps, setApps] = useState<AppRow[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editApp, setEditApp] = useState<AppRow | null>(null);
  const [loading, setLoading] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [a, m, s] = await Promise.all([
        fetch("/api/apps?limit=100").then((r) => r.json()),
        fetch("/api/messages").then((r) => r.json()),
        fetch("/api/stats").then((r) => r.json()),
      ]);
      setApps(a.apps || []);
      setMessages(m.messages || []);
      setStats(s.stats);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetch("/api/admin/me")
      .then((r) => r.json())
      .then((d) => setAuthed(d.authed))
      .catch(() => setAuthed(false));
  }, []);

  useEffect(() => {
    if (authed) loadData();
  }, [authed, loadData]);

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    setAuthed(false);
  }

  async function deleteApp(id: number) {
    if (!confirm("Pakka delete karna hai?")) return;
    await fetch(`/api/apps/${id}`, { method: "DELETE" });
    loadData();
  }

  async function toggleFeatured(app: AppRow) {
    await fetch(`/api/apps/${app.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ featured: !app.featured }),
    });
    loadData();
  }

  async function deleteMessage(id: number) {
    await fetch(`/api/messages/${id}`, { method: "DELETE" });
    loadData();
  }

  if (authed === null) {
    return (
      <div className="flex min-h-screen items-center justify-center pt-20">
        <Loader2 size={32} className="animate-spin text-violet-400" />
      </div>
    );
  }

  if (!authed) return <LoginScreen onLogin={() => setAuthed(true)} />;

  const tabs: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "apps", label: "Apps", icon: AppWindow },
    { id: "settings", label: "Settings", icon: Settings },
    { id: "messages", label: "Messages", icon: Inbox },
  ];

  return (
    <div className="min-h-screen pt-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        {/* header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold text-white md:text-4xl">
              Admin <span className="text-gradient">Panel</span>
            </h1>
            <p className="mt-1 text-sm text-zinc-500">
              Apni apps manage karo, settings badlo, messages padho.
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={loadData}
              className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-zinc-300 hover:text-white"
            >
              <RefreshCw size={15} className={loading ? "animate-spin" : ""} />
              Refresh
            </button>
            <button
              onClick={logout}
              className="flex items-center gap-2 rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-2.5 text-sm font-semibold text-rose-300 hover:bg-rose-500/20"
            >
              <LogOut size={15} />
              Logout
            </button>
          </div>
        </div>

        {/* tabs */}
        <div className="mt-8 flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition-all ${
                tab === t.id
                  ? "bg-gradient-to-r from-violet-600 to-cyan-500 text-white shadow-[0_0_24px_rgba(139,92,246,0.4)]"
                  : "border border-white/10 bg-white/[0.04] text-zinc-400 hover:text-white"
              }`}
            >
              <t.icon size={15} />
              {t.label}
              {t.id === "messages" && stats?.messageCount ? (
                <span className="rounded-full bg-cyan-500 px-2 py-0.5 text-[10px] font-bold text-black">
                  {stats.messageCount}
                </span>
              ) : null}
            </button>
          ))}
        </div>

        {/* content */}
        <div className="mt-8 pb-20">
          {tab === "overview" && (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: AppWindow, label: "Total Apps", value: stats?.appCount ?? 0, color: "text-violet-400" },
                { icon: Download, label: "Total Downloads", value: stats?.totalDownloads ?? 0, color: "text-cyan-400" },
                { icon: MessageSquare, label: "Reviews", value: stats?.reviewCount ?? 0, color: "text-fuchsia-400" },
                { icon: Star, label: "Avg Rating", value: stats?.avgRating?.toFixed(1) ?? "0", color: "text-amber-400" },
              ].map((s) => (
                <div key={s.label} className="gradient-border rounded-3xl p-6">
                  <s.icon size={22} className={s.color} />
                  <p className="mt-4 font-display text-4xl font-bold text-white">
                    {typeof s.value === "number" ? s.value.toLocaleString("en-IN") : s.value}
                  </p>
                  <p className="mt-1 text-xs uppercase tracking-widest text-zinc-500">{s.label}</p>
                </div>
              ))}
            </div>
          )}

          {tab === "apps" && (
            <div>
              <div className="flex justify-end">
                <button
                  onClick={() => {
                    setEditApp(null);
                    setShowForm(true);
                  }}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-5 py-2.5 text-sm font-bold text-white shadow-[0_0_24px_rgba(139,92,246,0.4)]"
                >
                  <Plus size={16} />
                  Upload New App
                </button>
              </div>

              <div className="mt-6 space-y-3">
                {apps.length === 0 && (
                  <div className="rounded-3xl border border-dashed border-white/15 p-16 text-center text-zinc-500">
                    Abhi koi app nahi hai. &quot;Upload New App&quot; se pehli app add karo.
                  </div>
                )}
                {apps.map((a) => (
                  <div
                    key={a.id}
                    className="flex flex-wrap items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4"
                  >
                    <AppIcon name={a.name} iconUrl={a.iconUrl} className="h-14 w-14" />
                    <div className="min-w-0 flex-1">
                      <p className="font-display font-bold text-white">{a.name}</p>
                      <p className="text-xs text-zinc-500">
                        {a.category} · v{a.version} · {a.downloads.toLocaleString("en-IN")} downloads
                        {!a.published && " · Draft"}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleFeatured(a)}
                      title="Toggle featured"
                      className={`rounded-lg p-2.5 transition-all ${
                        a.featured
                          ? "bg-amber-500/15 text-amber-400"
                          : "bg-white/5 text-zinc-500 hover:text-white"
                      }`}
                    >
                      <Star size={16} className={a.featured ? "fill-amber-400" : ""} />
                    </button>
                    <button
                      onClick={() => {
                        setEditApp(a);
                        setShowForm(true);
                      }}
                      title="Edit"
                      className="rounded-lg bg-white/5 p-2.5 text-zinc-400 hover:text-cyan-300"
                    >
                      <Pencil size={16} />
                    </button>
                    <a
                      href={`/apps/${a.slug}`}
                      target="_blank"
                      title="View"
                      className="rounded-lg bg-white/5 p-2.5 text-zinc-400 hover:text-white"
                    >
                      <Eye size={16} />
                    </a>
                    <button
                      onClick={() => deleteApp(a.id)}
                      title="Delete"
                      className="rounded-lg bg-white/5 p-2.5 text-zinc-400 hover:text-rose-400"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "settings" && <SettingsTab />}

          {tab === "messages" && (
            <div className="space-y-3">
              {messages.length === 0 && (
                <div className="rounded-3xl border border-dashed border-white/15 p-16 text-center text-zinc-500">
                  Koi message nahi aaya abhi.
                </div>
              )}
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`rounded-2xl border p-5 ${
                    m.read ? "border-white/10 bg-white/[0.02]" : "border-cyan-400/30 bg-cyan-500/5"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-white">
                        {m.name}{" "}
                        <span className="ml-2 text-xs font-normal text-zinc-500">{m.email}</span>
                      </p>
                      <p className="mt-0.5 text-[11px] text-zinc-600">
                        {new Date(m.createdAt).toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {!m.read && (
                        <button
                          onClick={async () => {
                            await fetch(`/api/messages/${m.id}`, {
                              method: "PATCH",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ read: true }),
                            });
                            loadData();
                          }}
                          className="rounded-lg bg-white/5 p-2 text-zinc-400 hover:text-emerald-300"
                          title="Mark read"
                        >
                          <EyeOff size={15} />
                        </button>
                      )}
                      <button
                        onClick={() => deleteMessage(m.id)}
                        className="rounded-lg bg-white/5 p-2 text-zinc-400 hover:text-rose-400"
                        title="Delete"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-zinc-300">{m.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showForm && (
        <AppForm
          app={editApp}
          onClose={() => setShowForm(false)}
          onSaved={() => {
            setShowForm(false);
            setEditApp(null);
            loadData();
          }}
        />
      )}
    </div>
  );
}

/* ---------------- Login ---------------- */

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "Login failed");
      }
      onLogin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center px-5 pt-20">
      <div className="orb left-1/3 top-1/4 h-80 w-80 bg-violet-700/25" />
      <div className="orb bottom-1/4 right-1/3 h-80 w-80 bg-cyan-600/20" />

      <div className="gradient-border relative w-full max-w-md rounded-[2rem] p-9">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-cyan-500 shadow-[0_0_40px_rgba(139,92,246,0.5)]">
          <Lock size={26} className="text-white" />
        </div>
        <h1 className="mt-6 font-display text-3xl font-bold text-white">Admin Login</h1>
        <p className="mt-2 text-sm text-zinc-500">
          Sirf Ankit ke liye. Password daalo aur panel kholo.
        </p>

        {error && (
          <div className="mt-5 rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="relative">
            <input
              type={show ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Admin password"
              required
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3.5 pr-12 text-sm text-white placeholder-zinc-600 outline-none transition-all focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/20"
            />
            <button
              type="button"
              onClick={() => setShow(!show)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
            >
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          <button
            type="submit"
            disabled={busy}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-3.5 font-display font-bold text-white shadow-[0_0_28px_rgba(139,92,246,0.4)] transition-all hover:shadow-[0_0_40px_rgba(34,211,238,0.55)] disabled:opacity-60"
          >
            {busy && <Loader2 size={16} className="animate-spin" />}
            Enter Panel
          </button>
        </form>

        <p className="mt-5 text-center text-xs text-zinc-600">
          Default password: <code className="rounded bg-white/10 px-1.5 py-0.5 text-zinc-400">ankit@2024</code>
          <br />(ADMIN_PASSWORD env se change kar sakte ho)
        </p>
      </div>
    </div>
  );
}

/* ---------------- Settings ---------------- */

function SettingsTab() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => setSettings(d.settings || {}));
  }, []);

  async function uploadLogo(file: File) {
    setBusy("logo");
    const fd = new FormData();
    fd.append("file", file);
    fd.append("kind", "logo");
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (res.ok) setSettings((s) => ({ ...s, site_logo: data.url }));
    setBusy("");
  }

  async function save() {
    setBusy("save");
    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    });
    setBusy("");
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  const inputCls =
    "w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 outline-none transition-all focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/20";
  const labelCls = "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-zinc-500";

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="gradient-border rounded-3xl p-7">
        <h3 className="font-display text-xl font-bold text-white">Branding</h3>
        <div className="mt-5 space-y-4">
          <div>
            <label className={labelCls}>Site Logo</label>
            <div className="flex items-center gap-4">
              {settings.site_logo && (
                <img
                  src={settings.site_logo}
                  alt="logo"
                  className="h-16 w-16 rounded-2xl border border-white/15 object-cover"
                />
              )}
              <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-white/20 px-4 py-2.5 text-xs font-semibold text-zinc-400 transition-colors hover:border-violet-400/50 hover:text-white">
                {busy === "logo" ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <Upload size={14} />
                )}
                Upload logo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && uploadLogo(e.target.files[0])}
                />
              </label>
            </div>
          </div>
          <div>
            <label className={labelCls}>Site Title</label>
            <input
              className={inputCls}
              value={settings.site_title || ""}
              onChange={(e) => setSettings({ ...settings, site_title: e.target.value })}
              placeholder="Ankit"
            />
          </div>
          <div>
            <label className={labelCls}>Hero Title</label>
            <input
              className={inputCls}
              value={settings.hero_title || ""}
              onChange={(e) => setSettings({ ...settings, hero_title: e.target.value })}
              placeholder="Apps that feel alive."
            />
          </div>
        </div>
        <button
          onClick={save}
          disabled={busy === "save"}
          className="mt-6 flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-3 font-display text-sm font-bold text-white shadow-[0_0_24px_rgba(139,92,246,0.4)] disabled:opacity-60"
        >
          {busy === "save" ? <Loader2 size={15} className="animate-spin" /> : null}
          {saved ? "Saved!" : "Save Settings"}
        </button>
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-7">
        <h3 className="font-display text-xl font-bold text-white">Upload Guide</h3>
        <div className="mt-4 space-y-4 text-sm leading-relaxed text-zinc-400">
          <p>
            <span className="font-semibold text-white">1.</span> Apps tab kholo → &quot;Upload New
            App&quot; button dabao.
          </p>
          <p>
            <span className="font-semibold text-white">2.</span> App ki details bharo — naam,
            tagline, description, features (line by line).
          </p>
          <p>
            <span className="font-semibold text-white">3.</span> Icon aur screenshots upload karo
            (image files), APK bhi directly upload ho jayega.
          </p>
          <p>
            <span className="font-semibold text-white">4.</span> &quot;Featured&quot; tick karoge to
            app home page par dikhegi.
          </p>
          <p>
            <span className="font-semibold text-white">5.</span> Logo yahin se change kar sakte ho —
            jo aapne diya hai wo upload kar dena.
          </p>
        </div>
      </div>
    </div>
  );
}
