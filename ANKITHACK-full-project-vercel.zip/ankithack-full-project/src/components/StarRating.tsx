"use client";

import { useState } from "react";
import { Star } from "lucide-react";

export function StarsDisplay({ value, size = 14 }: { value: number; size?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={size}
          className={
            i <= Math.round(value)
              ? "fill-amber-400 text-amber-400"
              : "fill-zinc-800 text-zinc-700"
          }
        />
      ))}
    </div>
  );
}

export function StarsInput({
  value,
  onChange,
}: {
  value: number;
  onChange: (v: number) => void;
}) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          onMouseEnter={() => setHover(i)}
          onMouseLeave={() => setHover(0)}
          onClick={() => onChange(i)}
          className="transition-transform hover:scale-125"
          aria-label={`${i} star`}
        >
          <Star
            size={22}
            className={
              i <= (hover || value)
                ? "fill-amber-400 text-amber-400"
                : "fill-zinc-800 text-zinc-600"
            }
          />
        </button>
      ))}
    </div>
  );
}
