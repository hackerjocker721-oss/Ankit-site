"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, useScroll, useSpring } from "framer-motion";
import { Menu, X, LayoutGrid, Home, ShieldCheck } from "lucide-react";

export default function Navbar({ logo, title }: { logo: string; title: string }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 24, mass: 0.4 });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const links = [
    { href: "/", label: "Home", icon: Home },
    { href: "/apps", label: "App Library", icon: LayoutGrid },
    { href: "/admin", label: "Admin", icon: ShieldCheck },
  ];

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "glass-strong py-2.5 shadow-[0_8px_40px_rgba(0,0,0,0.45)]" : "bg-transparent py-5"
      }`}
    >
      <motion.div
        style={{ scaleX: progress }}
        className="absolute inset-x-0 top-0 h-[2px] origin-left bg-gradient-to-r from-violet-500 via-fuchsia-400 to-cyan-400"
      />
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 md:px-8">
        <Link href="/" className="group flex items-center gap-3">
          <span className="relative">
            <img
              src={logo}
              alt={title}
              className="h-10 w-10 rounded-xl border border-white/15 shadow-[0_0_24px_rgba(139,92,246,0.5)] transition-transform duration-500 group-hover:rotate-[10deg] group-hover:scale-110"
            />
          </span>
          <span className="font-display text-xl font-bold tracking-tight text-white">
            {title}
            <span className="text-cyan-400">.</span>
          </span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          {links.map((l) => {
            const active = pathname === l.href;
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`relative rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  active ? "text-white" : "text-zinc-400 hover:text-white"
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-0 rounded-full bg-white/10 ring-1 ring-white/15"
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
                <span className="relative flex items-center gap-2">
                  <l.icon size={15} />
                  {l.label}
                </span>
              </Link>
            );
          })}
          <a
            href="/#contact"
            className="ml-3 rounded-full bg-gradient-to-r from-violet-600 to-cyan-500 px-5 py-2 text-sm font-semibold text-white shadow-[0_0_24px_rgba(139,92,246,0.45)] transition-all hover:shadow-[0_0_36px_rgba(34,211,238,0.6)]"
          >
            Get in touch
          </a>
        </div>

        <button
          onClick={() => setOpen(!open)}
          className="rounded-lg border border-white/10 bg-white/5 p-2 text-white md:hidden"
          aria-label="Toggle menu"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {open && (
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-strong mx-4 mt-3 rounded-2xl p-4 md:hidden"
        >
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-zinc-300 hover:bg-white/5 hover:text-white"
            >
              <l.icon size={16} />
              {l.label}
            </Link>
          ))}
        </motion.div>
      )}
    </header>
  );
}
