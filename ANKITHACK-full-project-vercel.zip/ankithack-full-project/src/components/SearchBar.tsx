"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Search, X } from "lucide-react";

export default function SearchBar() {
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") || "");

  useEffect(() => {
    setQ(params.get("q") || "");
  }, [params]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const category = params.get("category");
    const sp = new URLSearchParams();
    if (q.trim()) sp.set("q", q.trim());
    if (category) sp.set("category", category);
    router.push(`/apps${sp.toString() ? `?${sp}` : ""}`);
  }

  return (
    <form
      onSubmit={submit}
      className="group relative mx-auto w-full max-w-xl"
    >
      <Search
        size={18}
        className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-500 transition-colors group-focus-within:text-cyan-400"
      />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search apps..."
        className="w-full rounded-2xl border border-white/10 bg-white/[0.04] py-4 pl-13 pr-12 text-sm text-white placeholder-zinc-600 outline-none backdrop-blur transition-all focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/25"
        style={{ paddingLeft: "3.25rem" }}
      />
      {q && (
        <button
          type="button"
          onClick={() => {
            setQ("");
            const category = params.get("category");
            router.push(category ? `/apps?category=${encodeURIComponent(category)}` : "/apps");
          }}
          className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-1 text-zinc-400 hover:text-white"
          aria-label="Clear"
        >
          <X size={14} />
        </button>
      )}
    </form>
  );
}
