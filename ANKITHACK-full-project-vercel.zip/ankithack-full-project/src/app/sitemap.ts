import type { MetadataRoute } from "next";
import { db } from "@/db";
import { apps } from "@/db/schema";
import { eq } from "drizzle-orm";
import { siteUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();

  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: `${base}/`,
      lastModified: new Date(),
      changeFrequency: "daily",
      priority: 1,
    },
    {
      url: `${base}/apps`,
      lastModified: new Date(),
      changeFrequency: "daily",
      priority: 0.9,
    },
  ];

  try {
    const rows = await db
      .select({ slug: apps.slug, updatedAt: apps.updatedAt })
      .from(apps)
      .where(eq(apps.published, true));

    const appRoutes: MetadataRoute.Sitemap = rows.map((r) => ({
      url: `${base}/apps/${r.slug}`,
      lastModified: r.updatedAt ?? new Date(),
      changeFrequency: "weekly",
      priority: 0.8,
    }));

    return [...staticRoutes, ...appRoutes];
  } catch {
    return staticRoutes;
  }
}
