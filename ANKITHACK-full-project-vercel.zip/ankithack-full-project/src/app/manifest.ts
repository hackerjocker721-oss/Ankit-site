import type { MetadataRoute } from "next";
import { FALLBACK_SITE_NAME, FALLBACK_TAGLINE, getSiteBranding } from "@/lib/site";

export default async function manifest(): Promise<MetadataRoute.Manifest> {
  const brand = await getSiteBranding();
  return {
    name: `${brand.name} — ${FALLBACK_TAGLINE}`,
    short_name: brand.name || FALLBACK_SITE_NAME,
    description: `Download handcrafted apps from ${brand.name}. A 3D app store experience.`,
    start_url: "/",
    display: "standalone",
    background_color: "#05050d",
    theme_color: "#05050d",
    orientation: "portrait",
    categories: ["apps", "entertainment", "utilities"],
    icons: [
      {
        src: "/images/ankithack-logo.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/images/ankithack-logo.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/images/ankithack-logo.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
