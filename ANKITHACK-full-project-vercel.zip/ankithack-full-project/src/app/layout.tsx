import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getSiteBranding, siteUrl, FALLBACK_TAGLINE } from "@/lib/site";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
});

export async function generateMetadata(): Promise<Metadata> {
  const brand = await getSiteBranding();
  const base = siteUrl();
  const description = `${brand.name} — ${FALLBACK_TAGLINE} Download handcrafted apps built with obsession. 3D app store experience with a curated library of fast, secure and beautiful apps.`;
  const verification = process.env.GOOGLE_SITE_VERIFICATION;

  return {
    metadataBase: new URL(base),
    title: {
      default: `${brand.name} — ${FALLBACK_TAGLINE}`,
      template: `%s | ${brand.name}`,
    },
    description,
    applicationName: brand.name,
    keywords: [
      brand.name,
      "ankithack",
      "Ankit apps",
      "app store",
      "download android apps",
      "3D app store",
      "indie developer apps",
      "apk download",
      "handcrafted apps",
    ],
    authors: [{ name: "Ankit" }],
    creator: "Ankit",
    publisher: brand.name,
    alternates: { canonical: "/" },
    manifest: "/manifest.webmanifest",
    icons: {
      icon: [
        { url: "/images/ankithack-logo.png", type: "image/png" },
      ],
      apple: [{ url: "/images/ankithack-logo.png" }],
    },
    openGraph: {
      type: "website",
      url: base,
      siteName: brand.name,
      title: `${brand.name} — ${FALLBACK_TAGLINE}`,
      description,
      images: [
        {
          url: "/images/og-cover.jpg",
          width: 1200,
          height: 630,
          alt: `${brand.name} app store`,
        },
      ],
      locale: "en_US",
    },
    twitter: {
      card: "summary_large_image",
      title: `${brand.name} — ${FALLBACK_TAGLINE}`,
      description,
      images: ["/images/og-cover.jpg"],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: { index: true, follow: true, "max-image-preview": "large" },
    },
    ...(verification ? { verification: { google: verification } } : {}),
  };
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const brand = await getSiteBranding();
  const base = siteUrl();

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${base}/#organization`,
        name: brand.name,
        url: base,
        logo: `${base}${brand.logo}`,
        description: `Independent app studio by Ankit publishing handcrafted mobile apps.`,
        founder: { "@type": "Person", name: "Ankit" },
      },
      {
        "@type": "WebSite",
        "@id": `${base}/#website`,
        url: base,
        name: brand.name,
        publisher: { "@id": `${base}/#organization` },
        inLanguage: "en",
        potentialAction: {
          "@type": "SearchAction",
          target: {
            "@type": "EntryPoint",
            urlTemplate: `${base}/apps?q={search_term_string}`,
          },
          "query-input": "required name=search_term_string",
        },
      },
    ],
  };

  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="noise min-h-screen bg-[#05050d] font-body text-zinc-200 antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Navbar logo={brand.logo} title={brand.name} />
        <main>{children}</main>
        <Footer logo={brand.logo} title={brand.name} />
      </body>
    </html>
  );
}
