import Link from "next/link";
import { Home, AppWindow } from "lucide-react";

export default function NotFound() {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center px-5 text-center">
      <div className="orb left-1/4 top-1/4 h-80 w-80 bg-violet-700/25" />
      <div className="orb bottom-1/4 right-1/4 h-80 w-80 bg-cyan-600/20" />
      <p className="text-stroke relative font-display text-[10rem] font-bold leading-none md:text-[14rem]">
        404
      </p>
      <h1 className="relative mt-2 font-display text-2xl font-bold text-white">
        Yeh page universe mein <span className="text-gradient">exist nahi karta</span>
      </h1>
      <p className="relative mt-3 max-w-sm text-sm text-zinc-500">
        Jo app dhoond rahe ho wo shayad hata di gayi hai ya link galat hai.
      </p>
      <div className="relative mt-8 flex gap-4">
        <Link
          href="/"
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-3 text-sm font-bold text-white"
        >
          <Home size={15} />
          Home
        </Link>
        <Link
          href="/apps"
          className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-zinc-200"
        >
          <AppWindow size={15} />
          Browse Apps
        </Link>
      </div>
    </div>
  );
}
