import Link from "next/link";
import {
  ArrowRight,
  Zap,
  ShieldCheck,
  Sparkles,
  Rocket,
  Star,
  Download,
  AppWindow,
  Layers,
  HeartHandshake,
  Gauge,
  Eye,
} from "lucide-react";
import { db } from "@/db";
import { apps, settings } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";
import AppCard, { type AppCardData } from "@/components/AppCard";
import Reveal from "@/components/Reveal";
import Counter from "@/components/Counter";
import HeroSceneClient from "@/components/HeroSceneClient";

export const dynamic = "force-dynamic";

async function getHomeData() {
  try {
    const featured = await db
      .select()
      .from(apps)
      .where(and(eq(apps.published, true), eq(apps.featured, true)))
      .orderBy(desc(apps.downloads))
      .limit(6);

    const latest = await db
      .select()
      .from(apps)
      .where(eq(apps.published, true))
      .orderBy(desc(apps.createdAt))
      .limit(6);

    const all = await db.select().from(apps).where(eq(apps.published, true));
    const totalDownloads = all.reduce((s, a) => s + a.downloads, 0);
    const categories = [...new Set(all.map((a) => a.category))];
    const rated = all.filter((a) => a.ratingCount > 0);
    const avgRating =
      rated.length > 0
        ? rated.reduce((s, a) => s + a.ratingAvg, 0) / rated.length
        : 0;

    const settingRows = await db.select().from(settings);
    const siteSettings: Record<string, string> = {};
    for (const r of settingRows) siteSettings[r.key] = r.value;

    return {
      featured,
      latest,
      stats: { appCount: all.length, totalDownloads, categories: categories.length, avgRating },
      settings: siteSettings,
    };
  } catch {
    return {
      featured: [] as AppCardData[],
      latest: [] as AppCardData[],
      stats: { appCount: 0, totalDownloads: 0, categories: 0, avgRating: 0 },
      settings: {} as Record<string, string>,
    };
  }
}

const WHY_FEATURES = [
  {
    icon: Zap,
    title: "Blazing Fast",
    desc: "Har app performance-first architecture ke saath bani hai — 60fps hamesha.",
    color: "text-amber-400",
    bg: "from-amber-500/15",
  },
  {
    icon: ShieldCheck,
    title: "Safe & Secure",
    desc: "Har upload manually verify hota hai. No malware, no tracking, no nonsense.",
    color: "text-emerald-400",
    bg: "from-emerald-500/15",
  },
  {
    icon: Sparkles,
    title: "Handcrafted UI",
    desc: "Har app ka interface personally design kiya gaya hai — templates nahi, craft.",
    color: "text-fuchsia-400",
    bg: "from-fuchsia-500/15",
  },
  {
    icon: Rocket,
    title: "Regular Updates",
    desc: "Bugs fix hote rehte hain aur naye features regularly aate hain.",
    color: "text-cyan-400",
    bg: "from-cyan-500/15",
  },
  {
    icon: Gauge,
    title: "Lightweight",
    desc: "Optimized builds — kam storage, kam battery, zyada productivity.",
    color: "text-violet-400",
    bg: "from-violet-500/15",
  },
  {
    icon: HeartHandshake,
    title: "User First",
    desc: "Aapka feedback directly roadmap banata hai. Review likho, suna jayega.",
    color: "text-rose-400",
    bg: "from-rose-500/15",
  },
];

export default async function HomePage() {
  const { featured, latest, stats, settings } = await getHomeData();
  const showcase = featured.length > 0 ? featured : latest;
  const heroTitle = settings.hero_title?.trim();
  const siteName = settings.site_title?.trim() || "AnkitHack";

  return (
    <div className="relative">
      {/* ============ HERO ============ */}
      <section className="relative flex min-h-[100svh] items-center overflow-hidden">
        <div className="absolute inset-0">
          <HeroSceneClient />
        </div>
        <div className="orb left-[-10%] top-[-10%] h-[34rem] w-[34rem] bg-violet-700/20" />
        <div className="orb bottom-[-15%] right-[-8%] h-[30rem] w-[30rem] bg-cyan-600/15" />

        {/* giant watermark */}
        <div className="pointer-events-none absolute inset-x-0 bottom-6 select-none overflow-hidden text-center">
          <span className="text-stroke font-display text-[18vw] font-bold leading-none tracking-tighter">
            APPS
          </span>
        </div>

        <div className="relative z-10 mx-auto w-full max-w-7xl px-5 pt-28 md:px-8">
          <div className="max-w-3xl">
            <Reveal>
              <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/30 bg-violet-500/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-violet-300">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-cyan-400" />
                </span>
                The 3D App Universe
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight text-white sm:text-6xl md:text-7xl">
                {heroTitle ? (
                  heroTitle
                ) : (
                  <>
                    Apps that
                    <br />
                    feel <span className="text-gradient">alive.</span>
                  </>
                )}
              </h1>
            </Reveal>

            <Reveal delay={0.2}>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-zinc-400">
                Welcome to <span className="font-semibold text-white">{siteName}</span> — ek
                curated universe of handcrafted apps. Har app ek story hai, ek obsession hai.
                Download karo, experience karo.
              </p>
            </Reveal>

            <Reveal delay={0.3}>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <Link
                  href="/apps"
                  className="group relative flex items-center gap-2 overflow-hidden rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 px-8 py-4 font-display font-bold text-white shadow-[0_0_40px_rgba(139,92,246,0.45)] transition-all hover:scale-[1.03] hover:shadow-[0_0_60px_rgba(34,211,238,0.6)]"
                >
                  <span className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                  <AppWindow size={19} />
                  Explore Apps
                  <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
                </Link>
                <a
                  href="#featured"
                  className="rounded-2xl border border-white/15 bg-white/5 px-8 py-4 font-display font-bold text-zinc-200 backdrop-blur transition-all hover:border-cyan-400/50 hover:text-white"
                >
                  Featured
                </a>
              </div>
            </Reveal>

            <Reveal delay={0.4}>
              <div className="mt-12 flex flex-wrap gap-8">
                {[
                  { label: "Apps", value: stats.appCount, suffix: "+" },
                  { label: "Downloads", value: stats.totalDownloads, suffix: "+" },
                  { label: "Avg Rating", value: stats.avgRating, suffix: "★", decimals: 1 },
                ].map((s) => (
                  <div key={s.label}>
                    <p className="font-display text-3xl font-bold text-white">
                      <Counter value={s.value} suffix={s.suffix} decimals={s.decimals ?? 0} />
                    </p>
                    <p className="mt-1 text-xs uppercase tracking-widest text-zinc-500">{s.label}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>

        {/* scroll hint */}
        <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2">
          <div className="flex h-12 w-7 items-start justify-center rounded-full border border-white/20 p-1.5">
            <div className="h-2.5 w-1 animate-bounce rounded-full bg-cyan-400" />
          </div>
        </div>
      </section>

      {/* ============ MARQUEE ============ */}
      <div className="relative border-y border-white/10 bg-white/[0.02] py-4">
        <div className="flex overflow-hidden">
          <div className="animate-marquee flex shrink-0 items-center gap-10 pr-10">
            {[...Array(2)].flatMap((_, k) =>
              ["Productivity", "Music & Audio", "Art & Design", "Health & Fitness", "Developer Tools", "Weather", "Photography", "Games", "Education", "Finance"].map((c, i) => (
                <span key={`${k}-${i}`} className="flex items-center gap-3 whitespace-nowrap font-display text-sm font-semibold uppercase tracking-[0.2em] text-zinc-600">
                  <Star size={12} className="text-violet-500" />
                  {c}
                </span>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ============ FEATURED APPS ============ */}
      <section id="featured" className="relative mx-auto max-w-7xl px-5 py-24 md:px-8">
        <div className="orb right-[-6%] top-10 h-96 w-96 bg-fuchsia-700/15" />
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
                Handpicked
              </p>
              <h2 className="mt-3 font-display text-4xl font-bold text-white md:text-5xl">
                Featured <span className="text-gradient">Apps</span>
              </h2>
            </div>
            <Link
              href="/apps"
              className="group flex items-center gap-2 text-sm font-semibold text-zinc-400 transition-colors hover:text-cyan-400"
            >
              View all apps
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {showcase.length > 0 ? (
            showcase.map((app, i) => (
              <Reveal key={app.id} delay={i * 0.08}>
                <AppCard app={app} index={i} />
              </Reveal>
            ))
          ) : (
            <div className="col-span-full rounded-3xl border border-dashed border-white/15 bg-white/[0.02] p-16 text-center">
              <AppWindow size={44} className="mx-auto text-zinc-600" />
              <p className="mt-4 font-display text-xl font-semibold text-white">Apps coming soon</p>
              <p className="mt-2 text-sm text-zinc-500">
                Admin panel se apni pehli app upload karo — yahan featured dikhegi.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* ============ WHY ANKIT ============ */}
      <section className="relative border-y border-white/10 bg-gradient-to-b from-white/[0.03] to-transparent py-24">
        <div className="orb left-[-8%] top-1/3 h-96 w-96 bg-violet-700/15" />
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <div className="mx-auto max-w-2xl text-center">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-violet-400">
                Why {siteName}
              </p>
              <h2 className="mt-3 font-display text-4xl font-bold text-white md:text-5xl">
                Not just apps. <span className="text-gradient">Experiences.</span>
              </h2>
              <p className="mt-5 leading-relaxed text-zinc-400">
                Har app ek idea se shuru hoti hai aur ek obsession ban jati hai.
                Quality over quantity — hamesha.
              </p>
            </div>
          </Reveal>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {WHY_FEATURES.map((f, i) => (
              <Reveal key={f.title} delay={i * 0.07}>
                <div className={`group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b ${f.bg} to-transparent p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-white/20`}>
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/5">
                    <f.icon size={22} className={f.color} />
                  </div>
                  <h3 className="mt-5 font-display text-lg font-bold text-white">{f.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-zinc-400">{f.desc}</p>
                  <div className="absolute -bottom-10 -right-10 h-28 w-28 rounded-full bg-white/5 blur-2xl transition-all duration-500 group-hover:bg-white/10" />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CATEGORIES ============ */}
      <section className="mx-auto max-w-7xl px-5 py-24 md:px-8">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-fuchsia-400">
                Browse
              </p>
              <h2 className="mt-3 font-display text-4xl font-bold text-white md:text-5xl">
                By <span className="text-gradient">Category</span>
              </h2>
            </div>
          </div>
        </Reveal>
        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {[
            { name: "Productivity", icon: Zap },
            { name: "Music & Audio", icon: Layers },
            { name: "Art & Design", icon: Eye },
            { name: "Health & Fitness", icon: Rocket },
            { name: "Developer Tools", icon: Sparkles },
          ].map((c, i) => (
            <Reveal key={c.name} delay={i * 0.06}>
              <Link
                href={`/apps?category=${encodeURIComponent(c.name)}`}
                className="group flex flex-col items-center gap-4 rounded-3xl border border-white/10 bg-white/[0.03] p-8 text-center transition-all duration-300 hover:-translate-y-1.5 hover:border-violet-400/40 hover:bg-violet-500/10"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600/30 to-cyan-500/30 text-cyan-300 transition-transform duration-500 group-hover:rotate-[10deg] group-hover:scale-110">
                  <c.icon size={24} />
                </div>
                <span className="font-display text-sm font-semibold text-zinc-300 group-hover:text-white">
                  {c.name}
                </span>
              </Link>
            </Reveal>
          ))}
          <Reveal delay={0.3}>
            <Link
              href="/apps"
              className="group flex h-full flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-white/15 p-8 text-center transition-all hover:border-cyan-400/50 hover:bg-cyan-500/5"
            >
              <span className="font-display text-2xl font-bold text-gradient">All</span>
              <span className="text-xs uppercase tracking-widest text-zinc-500">Categories</span>
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ============ STATS BAND ============ */}
      <section className="relative overflow-hidden border-y border-white/10 py-16">
        <div className="absolute inset-0 bg-gradient-to-r from-violet-900/30 via-transparent to-cyan-900/30" />
        <div className="relative mx-auto grid max-w-7xl grid-cols-2 gap-10 px-5 md:grid-cols-4 md:px-8">
          {[
            { icon: AppWindow, label: "Total Apps", value: stats.appCount, suffix: "+" },
            { icon: Download, label: "Total Downloads", value: stats.totalDownloads, suffix: "+" },
            { icon: Layers, label: "Categories", value: stats.categories, suffix: "" },
            { icon: Star, label: "Avg Rating", value: stats.avgRating, suffix: "★", decimals: 1 },
          ].map((s, i) => (
            <Reveal key={s.label} delay={i * 0.08}>
              <div className="flex flex-col items-center gap-2 text-center">
                <s.icon size={22} className="text-cyan-400" />
                <p className="font-display text-4xl font-bold text-white md:text-5xl">
                  <Counter value={s.value} suffix={s.suffix} decimals={s.decimals ?? 0} />
                </p>
                <p className="text-xs uppercase tracking-widest text-zinc-500">{s.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ============ CTA ============ */}
      <section className="relative mx-auto max-w-7xl px-5 py-28 md:px-8">
        <Reveal>
          <div className="gradient-border relative overflow-hidden rounded-[2.5rem] p-12 text-center md:p-20">
            <div className="orb left-1/2 top-0 h-72 w-72 -translate-x-1/2 -translate-y-1/2 bg-violet-600/30" />
            <div className="orb bottom-0 right-10 h-56 w-56 bg-cyan-500/25" />
            <div className="relative">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
                Join the universe
              </p>
              <h2 className="mx-auto mt-4 max-w-2xl font-display text-4xl font-bold leading-tight text-white md:text-5xl">
                Koi idea hai? <span className="text-gradient">Releases mein</span> aa jao.
              </h2>
              <p className="mx-auto mt-5 max-w-xl leading-relaxed text-zinc-400">
                {siteName} par har app ko equal attention milta hai. Agar aapne kuch banaya
                hai jo logon tak pahunchna chahiye, to yahan uski jagah hai.
              </p>
              <div className="mt-9 flex flex-wrap justify-center gap-4">
                <a
                  href="/#contact"
                  className="rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 px-8 py-4 font-display font-bold text-white shadow-[0_0_40px_rgba(139,92,246,0.4)] transition-all hover:scale-[1.03]"
                >
                  Contact Me
                </a>
                <Link
                  href="/apps"
                  className="rounded-2xl border border-white/15 bg-white/5 px-8 py-4 font-display font-bold text-zinc-200 transition-all hover:border-cyan-400/50"
                >
                  Browse Library
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
