import Link from "next/link";
import { notFound } from "next/navigation";
import {
  db,
} from "@/db";
import { apps, screenshots, reviews } from "@/db/schema";
import { eq, ne, and, desc } from "drizzle-orm";
import {
  Star,
  Download,
  Tag,
  HardDrive,
  GitBranch,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  Sparkles,
} from "lucide-react";
import PhoneMockup from "@/components/PhoneMockup";
import DownloadButton from "@/components/DownloadButton";
import ReviewSection from "@/components/ReviewSection";
import AppCard from "@/components/AppCard";
import Reveal from "@/components/Reveal";
import { StarsDisplay } from "@/components/StarRating";
import { siteUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

async function getApp(slug: string) {
  try {
    const rows = await db.select().from(apps).where(eq(apps.slug, slug)).limit(1);
    return rows[0] || null;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const app = await getApp(slug);
  if (!app) return { title: "App not found" };
  const title = `${app.name} — Download v${app.version}`;
  const description =
    app.tagline || `Download ${app.name} v${app.version} (${app.size}) free on AnkitHack.`;
  return {
    title,
    description,
    alternates: { canonical: `/apps/${app.slug}` },
    openGraph: {
      title,
      description,
      type: "website",
      images: [{ url: app.iconUrl || "/images/ankithack-logo.png" }],
    },
    twitter: {
      card: "summary",
      title,
      description,
      images: [app.iconUrl || "/images/ankithack-logo.png"],
    },
  };
}

export default async function AppDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const app = await getApp(slug);
  if (!app || !app.published) notFound();

  let shots: { id: number; url: string }[] = [];
  let appReviews: (typeof reviews.$inferSelect)[] = [];
  let related: (typeof apps.$inferSelect)[] = [];
  try {
    shots = await db.select().from(screenshots).where(eq(screenshots.appId, app.id));
    appReviews = await db
      .select()
      .from(reviews)
      .where(eq(reviews.appId, app.id))
      .orderBy(desc(reviews.createdAt))
      .limit(12);
    related = await db
      .select()
      .from(apps)
      .where(and(eq(apps.category, app.category), ne(apps.id, app.id), eq(apps.published, true)))
      .limit(3);
  } catch {
    /* render without extras */
  }

  const featureList = app.features
    .split("\n")
    .map((f) => f.trim())
    .filter(Boolean);

  const gradientPairs = [
    "from-violet-600/40 to-fuchsia-600/20",
    "from-cyan-500/40 to-blue-600/20",
    "from-fuchsia-600/40 to-rose-500/20",
    "from-emerald-500/40 to-teal-600/20",
  ];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: app.name,
    operatingSystem: "Android",
    applicationCategory: app.category,
    softwareVersion: app.version,
    fileSize: app.size,
    description: app.description || app.tagline || `${app.name} app by Ankit.`,
    image: app.iconUrl ? `${siteUrl()}${app.iconUrl}` : undefined,
    offers: { "@type": "Offer", price: "0", priceCurrency: "INR" },
    ...(app.ratingCount > 0
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: Number(app.ratingAvg.toFixed(1)),
            ratingCount: app.ratingCount,
            bestRating: 5,
            worstRating: 1,
          },
        }
      : {}),
    author: { "@type": "Person", name: "Ankit" },
  };

  return (
    <div className="relative min-h-screen pb-24 pt-28">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="orb left-[-12%] top-[-5%] h-[28rem] w-[28rem] bg-violet-700/20" />
      <div className="orb right-[-10%] top-1/4 h-96 w-96 bg-cyan-600/15" />

      <div className="relative mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <Link
            href="/apps"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-500 transition-colors hover:text-cyan-400"
          >
            <ChevronLeft size={16} />
            Back to library
          </Link>
        </Reveal>

        <div className="mt-8 grid items-start gap-12 lg:grid-cols-[auto_1fr]">
          {/* 3D Phone */}
          <Reveal delay={0.1} className="mx-auto lg:sticky lg:top-28">
            <PhoneMockup
              name={app.name}
              category={app.category}
              iconUrl={app.iconUrl}
              rating={app.ratingAvg}
              version={app.version}
            />
          </Reveal>

          {/* Info */}
          <div>
            <Reveal delay={0.15}>
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded-full border border-violet-400/40 bg-violet-500/10 px-4 py-1.5 text-xs font-semibold text-violet-300">
                  {app.category}
                </span>
                {app.featured && (
                  <span className="flex items-center gap-1.5 rounded-full border border-amber-400/40 bg-amber-500/10 px-4 py-1.5 text-xs font-semibold text-amber-300">
                    <Sparkles size={12} />
                    Featured
                  </span>
                )}
              </div>

              <h1 className="mt-5 font-display text-4xl font-bold text-white md:text-6xl">
                {app.name}
              </h1>
              <p className="mt-3 max-w-xl text-lg text-zinc-400">{app.tagline}</p>

              <div className="mt-6 flex flex-wrap items-center gap-6">
                <div className="flex items-center gap-2">
                  <StarsDisplay value={app.ratingAvg} size={16} />
                  <span className="text-sm font-semibold text-white">
                    {app.ratingAvg > 0 ? app.ratingAvg.toFixed(1) : "New"}
                  </span>
                  {app.ratingCount > 0 && (
                    <span className="text-sm text-zinc-500">({app.ratingCount} reviews)</span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-sm text-zinc-400">
                  <Download size={15} />
                  {app.downloads.toLocaleString("en-IN")} downloads
                </div>
              </div>

              <div className="mt-8">
                <DownloadButton appId={app.id} disabled={!app.downloadUrl} />
              </div>

              {/* meta chips */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  { icon: GitBranch, label: "Version", value: app.version },
                  { icon: HardDrive, label: "Size", value: app.size },
                  { icon: Tag, label: "Category", value: app.category },
                  {
                    icon: CalendarDays,
                    label: "Updated",
                    value: new Date(app.updatedAt).toLocaleDateString("en-IN", {
                      day: "numeric",
                      month: "short",
                    }),
                  },
                ].map((m) => (
                  <div
                    key={m.label}
                    className="rounded-2xl border border-white/10 bg-white/[0.03] p-4"
                  >
                    <m.icon size={16} className="text-cyan-400" />
                    <p className="mt-2 text-[11px] uppercase tracking-wider text-zinc-500">
                      {m.label}
                    </p>
                    <p className="mt-0.5 truncate text-sm font-semibold text-white">{m.value}</p>
                  </div>
                ))}
              </div>
            </Reveal>

            {/* description */}
            <Reveal delay={0.2}>
              <div className="mt-12">
                <h2 className="font-display text-2xl font-bold text-white">
                  About this <span className="text-gradient">app</span>
                </h2>
                <p className="mt-4 max-w-2xl whitespace-pre-line leading-relaxed text-zinc-400">
                  {app.description || "Description coming soon."}
                </p>
              </div>
            </Reveal>

            {/* features */}
            {featureList.length > 0 && (
              <Reveal delay={0.25}>
                <div className="mt-10">
                  <h2 className="font-display text-2xl font-bold text-white">Features</h2>
                  <div className="mt-5 grid gap-3 sm:grid-cols-2">
                    {featureList.map((f, i) => (
                      <div
                        key={i}
                        className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-4"
                      >
                        <CheckCircle2 size={17} className="mt-0.5 shrink-0 text-emerald-400" />
                        <span className="text-sm text-zinc-300">{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Reveal>
            )}
          </div>
        </div>

        {/* screenshots */}
        <Reveal delay={0.1}>
          <div className="mt-20">
            <h2 className="font-display text-2xl font-bold text-white">
              Preview <span className="text-gradient">shots</span>
            </h2>
            <div className="mt-6 flex gap-5 overflow-x-auto pb-4">
              {(shots.length > 0
                ? shots.map((s) => ({ url: s.url, gradient: false }))
                : [0, 1, 2, 3].map((i) => ({ url: "", gradient: true, i }))
              ).map((s, idx) => (
                <div
                  key={idx}
                  className={`relative h-72 w-44 shrink-0 overflow-hidden rounded-3xl border border-white/10 ${
                    s.gradient
                      ? `bg-gradient-to-br ${gradientPairs[idx % gradientPairs.length]}`
                      : ""
                  }`}
                >
                  {s.gradient ? (
                    <div className="flex h-full items-center justify-center">
                      <span className="font-display text-5xl font-bold text-white/10">
                        {app.name}
                      </span>
                    </div>
                  ) : (
                    <img src={s.url} alt={`${app.name} screenshot ${idx + 1}`} className="h-full w-full object-cover" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* reviews */}
        <div className="mt-20">
          <ReviewSection appId={app.id} reviews={appReviews} />
        </div>

        {/* related */}
        {related.length > 0 && (
          <div className="mt-24">
            <Reveal>
              <h2 className="font-display text-2xl font-bold text-white">
                More in <span className="text-gradient">{app.category}</span>
              </h2>
            </Reveal>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((r, i) => (
                <Reveal key={r.id} delay={i * 0.08}>
                  <AppCard app={r} index={i} />
                </Reveal>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
