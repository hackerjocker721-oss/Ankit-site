import Link from "next/link";
import { Suspense } from "react";
import { db } from "@/db";
import { apps } from "@/db/schema";
import { desc, eq, and, ilike, or } from "drizzle-orm";
import AppCard from "@/components/AppCard";
import SearchBar from "@/components/SearchBar";
import Reveal from "@/components/Reveal";
import { AppWindow } from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "App Library — Browse & Download Apps",
  description:
    "Browse the full AnkitHack library. Handcrafted apps across productivity, music, design, fitness, developer tools and more — free to download.",
  alternates: { canonical: "/apps" },
};

async function getApps(q?: string, category?: string) {
  try {
    const conditions = [eq(apps.published, true)];
    if (q) {
      conditions.push(
        or(ilike(apps.name, `%${q}%`), ilike(apps.tagline, `%${q}%`), ilike(apps.category, `%${q}%`))!
      );
    }
    if (category) conditions.push(eq(apps.category, category));
    return await db
      .select()
      .from(apps)
      .where(and(...conditions))
      .orderBy(desc(apps.featured), desc(apps.downloads));
  } catch {
    return [];
  }
}

export default async function AppsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string }>;
}) {
  const sp = await searchParams;
  const q = sp.q;
  const category = sp.category;
  const list = await getApps(q, category);

  const categories = [
    "All",
    "Productivity",
    "Music & Audio",
    "Art & Design",
    "Health & Fitness",
    "Developer Tools",
    "Weather",
    "Photography",
    "Education",
    "Games",
    "Social",
    "Finance",
    "Other",
  ];

  function catHref(c: string) {
    const p = new URLSearchParams();
    if (c !== "All") p.set("category", c);
    if (q) p.set("q", q);
    return `/apps${p.toString() ? `?${p}` : ""}`;
  }

  return (
    <div className="relative min-h-screen pb-24 pt-32">
      <div className="orb left-[-10%] top-[-5%] h-96 w-96 bg-violet-700/20" />
      <div className="orb right-[-8%] top-1/3 h-96 w-96 bg-cyan-600/15" />

      <div className="relative mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="text-center">
            <p className="font-display text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
              The Library
            </p>
            <h1 className="mt-3 font-display text-5xl font-bold text-white md:text-6xl">
              App <span className="text-gradient">Library</span>
            </h1>
            <p className="mx-auto mt-4 max-w-md text-zinc-400">
              {list.length} app{list.length !== 1 ? "s" : ""} {category && category !== "All" ? `in ${category}` : "handcrafted with love"}
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-10">
            <Suspense>
              <SearchBar />
            </Suspense>
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="mt-8 flex flex-wrap justify-center gap-2">
            {categories.map((c) => {
              const active = (category || "All") === c;
              return (
                <Link
                  key={c}
                  href={catHref(c)}
                  className={`rounded-full px-4 py-2 text-xs font-semibold transition-all ${
                    active
                      ? "bg-gradient-to-r from-violet-600 to-cyan-500 text-white shadow-[0_0_20px_rgba(139,92,246,0.4)]"
                      : "border border-white/10 bg-white/[0.04] text-zinc-400 hover:border-violet-400/40 hover:text-white"
                  }`}
                >
                  {c}
                </Link>
              );
            })}
          </div>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.length > 0 ? (
            list.map((app, i) => (
              <Reveal key={app.id} delay={Math.min(i * 0.06, 0.4)}>
                <AppCard app={app} index={i} />
              </Reveal>
            ))
          ) : (
            <div className="col-span-full rounded-3xl border border-dashed border-white/15 bg-white/[0.02] p-20 text-center">
              <AppWindow size={48} className="mx-auto text-zinc-600" />
              <p className="mt-4 font-display text-xl font-semibold text-white">
                Koi app nahi mili
              </p>
              <p className="mt-2 text-sm text-zinc-500">
                Try a different search ya category filter hata do.
              </p>
              <Link
                href="/apps"
                className="mt-6 inline-block rounded-xl bg-gradient-to-r from-violet-600 to-cyan-500 px-6 py-2.5 text-sm font-semibold text-white"
              >
                Clear filters
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
