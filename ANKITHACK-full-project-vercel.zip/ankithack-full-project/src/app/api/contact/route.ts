import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body.name?.trim() || !body.email?.trim() || !body.message?.trim()) {
      return NextResponse.json({ error: "All fields required" }, { status: 400 });
    }
    const [created] = await db
      .insert(messages)
      .values({
        name: String(body.name).slice(0, 120).trim(),
        email: String(body.email).slice(0, 200).trim(),
        message: String(body.message).slice(0, 3000).trim(),
      })
      .returning();
    return NextResponse.json({ message: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 });
  }
}
