import { NextRequest, NextResponse } from "next/server";
import { readFile, stat } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

const MIME: Record<string, string> = {
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".apk": "application/vnd.android.package-archive",
  ".pdf": "application/pdf",
  ".txt": "text/plain",
};

const KINDS = new Set(["icon", "banner", "screenshots", "logo", "apk", "misc"]);

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ kind: string; name: string }> }
) {
  try {
    const { kind, name } = await params;
    if (!KINDS.has(kind) || name.includes("/") || name.includes("\\") || name.includes("..")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    const uploadsRoot = path.join(process.cwd(), "uploads");
    const filePath = path.join(uploadsRoot, kind, name);
    if (!filePath.startsWith(uploadsRoot)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    const info = await stat(filePath);
    if (!info.isFile()) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    const data = await readFile(filePath);
    const ext = path.extname(filePath).toLowerCase();
    return new NextResponse(new Uint8Array(data), {
      headers: {
        "Content-Type": MIME[ext] || "application/octet-stream",
        "Content-Length": String(info.size),
        "Cache-Control": "public, max-age=31536000, immutable",
        "Content-Disposition":
          ext === ".apk" ? `attachment; filename="${name}"` : "inline",
      },
    });
  } catch {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
}
