import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const KINDS = new Set(["icon", "banner", "screenshots", "logo", "apk", "misc"]);

const IMAGE_TYPES: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/svg+xml": "svg",
};

export async function POST(req: NextRequest) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const form = await req.formData();
    const file = form.get("file") as File | null;
    const kindRaw = String(form.get("kind") || "misc");
    const kind = KINDS.has(kindRaw) ? kindRaw : "misc";

    if (!file || typeof file === "string") {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const isApk =
      file.type === "application/vnd.android.package-archive" ||
      file.name.toLowerCase().endsWith(".apk");
    const maxBytes = isApk ? 200 * 1024 * 1024 : 10 * 1024 * 1024;

    if (file.size > maxBytes) {
      return NextResponse.json({ error: "File too large" }, { status: 413 });
    }
    if (!isApk && !(file.type in IMAGE_TYPES)) {
      return NextResponse.json({ error: "Only image files allowed" }, { status: 415 });
    }

    const safeBase = file.name
      .toLowerCase()
      .replace(/[^a-z0-9._-]/g, "-")
      .replace(/-+/g, "-")
      .slice(-60);
    const fileName = `${Date.now().toString(36)}-${safeBase || "file"}`;

    const dir = path.join(process.cwd(), "uploads", kind);
    await mkdir(dir, { recursive: true });
    const bytes = Buffer.from(await file.arrayBuffer());
    await writeFile(path.join(dir, fileName), bytes);

    return NextResponse.json({ url: `/api/files/${kind}/${fileName}` }, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }
}
