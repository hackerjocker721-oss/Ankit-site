import { NextResponse } from "next/server";
import { db } from "@/db";
import { apps, reviews, messages } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [appAgg] = await db
      .select({
        appCount: sql<number>`count(*)::int`,
        totalDownloads: sql<number>`coalesce(sum(${apps.downloads}), 0)::int`,
      })
      .from(apps)
      .where(eq(apps.published, true));

    const [ratingAgg] = await db
      .select({ avg: sql<number>`coalesce(avg(${apps.ratingAvg}), 0)::float` })
      .from(apps)
      .where(sql`${apps.ratingCount} > 0`);

    const [reviewAgg] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(reviews);

    const [msgAgg] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(messages)
      .where(eq(messages.read, false));

    return NextResponse.json({
      stats: {
        appCount: appAgg?.appCount ?? 0,
        totalDownloads: appAgg?.totalDownloads ?? 0,
        reviewCount: reviewAgg?.count ?? 0,
        messageCount: msgAgg?.count ?? 0,
        avgRating: ratingAgg?.avg ?? 0,
      },
    });
  } catch {
    return NextResponse.json({
      stats: { appCount: 0, totalDownloads: 0, reviewCount: 0, messageCount: 0, avgRating: 0 },
    });
  }
}
