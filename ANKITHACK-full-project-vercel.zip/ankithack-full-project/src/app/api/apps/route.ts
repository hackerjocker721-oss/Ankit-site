import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { apps, screenshots } from "@/db/schema";
import { desc, eq, and, ilike, or } from "drizzle-orm";
import { isAdmin } from "@/lib/auth";
import { slugify } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const search = sp.get("search") || sp.get("q");
    const category = sp.get("category");
    const featured = sp.get("featured");
    const limit = Math.min(parseInt(sp.get("limit") || "50", 10) || 50, 100);

    const conditions = [];
    if (search) {
      conditions.push(
        or(ilike(apps.name, `%${search}%`), ilike(apps.tagline, `%${search}%`))!
      );
    }
    if (category) conditions.push(eq(apps.category, category));
    if (featured === "true") conditions.push(eq(apps.featured, true));

    const rows = await db
      .select()
      .from(apps)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(apps.featured), desc(apps.downloads))
      .limit(limit);

    return NextResponse.json({ apps: rows });
  } catch (e) {
    return NextResponse.json({ error: "Failed to fetch apps" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await req.json();
    if (!body.name?.trim()) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const slug = (body.slug && slugify(body.slug)) || slugify(body.name);
    const existing = await db.select({ id: apps.id }).from(apps).where(eq(apps.slug, slug)).limit(1);
    const finalSlug = existing.length > 0 ? `${slug}-${Date.now().toString(36)}` : slug;

    const [created] = await db
      .insert(apps)
      .values({
        name: body.name.trim(),
        slug: finalSlug,
        tagline: body.tagline || "",
        description: body.description || "",
        features: body.features || "",
        category: body.category || "Other",
        version: body.version || "1.0.0",
        size: body.size || "10 MB",
        iconUrl: body.iconUrl || null,
        bannerUrl: body.bannerUrl || null,
        downloadUrl: body.downloadUrl || null,
        featured: !!body.featured,
        published: body.published !== false,
      })
      .returning();

    const shots: string[] = Array.isArray(body.screenshots) ? body.screenshots : [];
    if (shots.length > 0) {
      await db.insert(screenshots).values(
        shots.map((url, i) => ({ appId: created.id, url, sortOrder: i }))
      );
    }

    return NextResponse.json({ app: created }, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: "Failed to create app" }, { status: 500 });
  }
}
