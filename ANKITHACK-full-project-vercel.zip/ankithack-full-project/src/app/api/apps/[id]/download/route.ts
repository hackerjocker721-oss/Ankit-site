import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { apps } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const appId = parseInt(id, 10);
    const [updated] = await db
      .update(apps)
      .set({ downloads: sql`${apps.downloads} + 1` })
      .where(eq(apps.id, appId))
      .returning();

    if (!updated) return NextResponse.json({ error: "App not found" }, { status: 404 });
    return NextResponse.json({ url: updated.downloadUrl, downloads: updated.downloads });
  } catch {
    return NextResponse.json({ error: "Download failed" }, { status: 500 });
  }
}
