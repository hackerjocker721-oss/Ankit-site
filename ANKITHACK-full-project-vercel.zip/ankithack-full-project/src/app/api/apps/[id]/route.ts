import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { apps, screenshots } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const appId = parseInt(id, 10);
    const [app] = await db.select().from(apps).where(eq(apps.id, appId));
    if (!app) return NextResponse.json({ error: "App not found" }, { status: 404 });
    const shots = await db
      .select()
      .from(screenshots)
      .where(eq(screenshots.appId, appId));
    return NextResponse.json({ app, screenshots: shots });
  } catch {
    return NextResponse.json({ error: "Failed to fetch app" }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const { id } = await params;
    const appId = parseInt(id, 10);
    const body = await req.json();

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    const fields = [
      "name", "tagline", "description", "features", "category", "version",
      "size", "iconUrl", "bannerUrl", "downloadUrl", "featured", "published",
    ];
    for (const f of fields) {
      if (f in body) updates[f] = body[f];
    }

    const [updated] = await db
      .update(apps)
      .set(updates)
      .where(eq(apps.id, appId))
      .returning();

    if (!updated) return NextResponse.json({ error: "App not found" }, { status: 404 });

    if (Array.isArray(body.screenshots)) {
      await db.delete(screenshots).where(eq(screenshots.appId, appId));
      if (body.screenshots.length > 0) {
        await db.insert(screenshots).values(
          body.screenshots.map((url: string, i: number) => ({
            appId,
            url,
            sortOrder: i,
          }))
        );
      }
    }

    return NextResponse.json({ app: updated });
  } catch {
    return NextResponse.json({ error: "Failed to update app" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const { id } = await params;
    await db.delete(apps).where(eq(apps.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Failed to delete app" }, { status: 500 });
  }
}
