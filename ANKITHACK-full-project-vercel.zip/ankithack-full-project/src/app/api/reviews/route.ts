import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, apps } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function refreshRating(appId: number) {
  const [agg] = await db
    .select({
      avg: sql<number>`coalesce(avg(${reviews.rating}), 0)::float`,
      count: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(eq(reviews.appId, appId));
  await db
    .update(apps)
    .set({ ratingAvg: agg.avg, ratingCount: agg.count })
    .where(eq(apps.id, appId));
}

export async function GET(req: NextRequest) {
  try {
    const appId = req.nextUrl.searchParams.get("appId");
    const rows = appId
      ? await db.select().from(reviews).where(eq(reviews.appId, parseInt(appId, 10))).orderBy(desc(reviews.createdAt))
      : await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(100);
    return NextResponse.json({ reviews: rows });
  } catch {
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body.appId || !body.authorName?.trim()) {
      return NextResponse.json({ error: "appId and authorName required" }, { status: 400 });
    }
    const rating = Math.max(1, Math.min(5, parseInt(body.rating, 10) || 5));
    const [created] = await db
      .insert(reviews)
      .values({
        appId: parseInt(body.appId, 10),
        authorName: String(body.authorName).slice(0, 80).trim(),
        rating,
        comment: String(body.comment || "").slice(0, 1000),
      })
      .returning();
    await refreshRating(created.appId);
    return NextResponse.json({ review: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to submit review" }, { status: 500 });
  }
}
