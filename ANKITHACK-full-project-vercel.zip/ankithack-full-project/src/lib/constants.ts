export const CATEGORIES = [
  "Productivity",
  "Music & Audio",
  "Art & Design",
  "Health & Fitness",
  "Developer Tools",
  "Weather",
  "Photography",
  "Education",
  "Games",
  "Social",
  "Finance",
  "Other",
] as const;

export type Category = (typeof CATEGORIES)[number];

export const CATEGORY_ICONS: Record<string, string> = {
  Productivity: "Zap",
  "Music & Audio": "Music",
  "Art & Design": "Palette",
  "Health & Fitness": "Dumbbell",
  "Developer Tools": "Code",
  Weather: "CloudSun",
  Photography: "Camera",
  Education: "GraduationCap",
  Games: "Gamepad2",
  Social: "Users",
  Finance: "Wallet",
  Other: "AppWindow",
};

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
