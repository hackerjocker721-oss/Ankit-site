import { cookies } from "next/headers";

export const ADMIN_COOKIE = "ankit_admin";

export function getAdminPassword(): string {
  return process.env.ADMIN_PASSWORD || "ankit@2024";
}

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  return store.get(ADMIN_COOKIE)?.value === "1";
}
