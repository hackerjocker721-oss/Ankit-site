import { db } from "@/db";
import { settings } from "@/db/schema";

export const FALLBACK_SITE_NAME = "AnkitHack";
export const FALLBACK_TAGLINE = "Apps that feel alive.";

function rawSiteUrl(): string {
  return (
    process.env.NEXT_PUBLIC_SITE_URL ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "") ||
    (process.env.RENDER_EXTERNAL_URL as string | undefined) ||
    "http://localhost:3000"
  );
}

/** Public base URL of the site, always without a trailing slash. */
export function siteUrl(): string {
  return rawSiteUrl().replace(/\/+$/, "");
}

/** Reads branding overrides from the DB with safe fallbacks. */
export async function getSiteBranding(): Promise<{
  name: string;
  tagline: string;
  logo: string;
}> {
  let map: Record<string, string> = {};
  try {
    const rows = await db.select().from(settings);
    for (const r of rows) map[r.key] = r.value;
  } catch {
    map = {};
  }
  return {
    name: map.site_title?.trim() || FALLBACK_SITE_NAME,
    tagline: map.hero_title?.trim() || FALLBACK_TAGLINE,
    logo: map.site_logo || "/images/ankithack-logo.png",
  };
}
