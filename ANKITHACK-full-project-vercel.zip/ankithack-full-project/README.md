# ANKIT HACK

Full Next.js app for ANKIT + SHIV HACKER. This package preserves the original project instead of replacing it with a static HTML mockup.

- Home page with 3D hero
- App library and app detail pages
- Admin dashboard and app editor
- API routes for apps, reviews, contact messages, settings, stats, uploads and downloads
- PostgreSQL schema via Drizzle ORM
- SEO metadata, sitemap, robots, and PWA manifest

See `VERCEL-HINDI.md` for deployment steps and required environment variables. A PostgreSQL database is required for the server features. File uploads currently use local disk and need persistent object storage (e.g. Vercel Blob) for production durability.
