# ANKIT HACK — Vercel par full project deploy karne ki guide

**Zaroori:** Is project ko `index.html` mein convert mat karein. Ye Next.js app hai aur Admin Panel, API routes, database, reviews, messages, app details aur download tracking server-side code par depend karte hain. Sirf `index.html` se ye features kaam nahi karenge.

## 1. GitHub
1. ZIP extract karein.
2. Is folder ke andar ki saari files GitHub repository ke root mein upload karein. `package.json`, `src/`, `tsconfig.json` root par hone chahiye.
3. `node_modules` upload na karein.

## 2. PostgreSQL database
1. Neon ya Supabase mein PostgreSQL database banayein.
2. Connection string copy karein.
3. Vercel project ke **Settings → Environment Variables** mein ye variables add karein:
   - `DATABASE_URL` = database connection string
   - `ADMIN_PASSWORD` = strong, unique admin password (default password use na karein)
   - `NEXT_PUBLIC_SITE_URL` = deployed Vercel URL, e.g. `https://your-project.vercel.app`
   - `GOOGLE_SITE_VERIFICATION` optional
4. Environment variables ko Production, Preview aur Development mein jahan zaroorat ho set karein.

## 3. Vercel settings
1. Vercel → Add New → Project → GitHub repository import.
2. Framework Preset: **Next.js**.
3. Root Directory: project root (jahan `package.json` hai).
4. Build command: `npm run build` (default bhi theek hai).
5. Deploy karein.

## 4. Database tables aur demo data
Local terminal mein project folder ke andar:

```bash
npm install
```

`DATABASE_URL` environment variable set karne ke baad:

```bash
npx drizzle-kit push
```

Demo apps ke liye (optional), database connection string set hone par:

```bash
psql "$DATABASE_URL" -f seed.sql
```

Database tables create karne ke baad Vercel par redeploy karein. `/api/health` khol kar database connection test kar sakte hain; success par JSON `{"ok":true}` aana chahiye.

## 5. Admin Panel
- URL: `https://your-project.vercel.app/admin`
- Login password: Vercel ke `ADMIN_PASSWORD` environment variable mein set kiya hua password.
- Default development password `ankit@2024` ko live site par use na karein.

## 6. Important: uploaded files
Original code uploads ko project ke `uploads/` folder mein local disk par save karta hai. Vercel ka filesystem deployment ke beech persistent storage nahi hai. Isliye production par Admin Panel se upload ki gayi icons, banners aur APK files ko persistent rakhne ke liye Vercel Blob ya S3-compatible storage integration abhi add karni hogi. Database aur baaki server routes bhi tabhi kaam karenge jab `DATABASE_URL` sahi ho.

## 7. Quick checks
- `/` home page
- `/apps` app library
- `/admin` admin panel
- `/api/health` database status
- `/robots.txt`
- `/sitemap.xml`

Agar deploy fail ho, Vercel → Deployments → latest deployment → Build Logs ka error dekhein.
