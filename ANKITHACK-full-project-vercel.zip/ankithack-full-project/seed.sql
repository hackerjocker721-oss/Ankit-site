-- Ankit app store seed data
INSERT INTO settings (key, value) VALUES
  ('site_logo', '/images/ankithack-logo.png'),
  ('site_title', 'AnkitHack'),
  ('hero_title', 'Apps that feel alive.')
ON CONFLICT (key) DO NOTHING;

INSERT INTO apps (name, slug, tagline, description, features, category, version, size, icon_url, download_url, downloads, rating_avg, rating_count, featured, published) VALUES
('NeonBeat', 'neonbeat',
 'Music player with a live 3D visualizer',
 'NeonBeat ek music player hai jo aapki playlist ko ek show bana deta hai. Real-time 3D visualizer, 10-band equalizer aur gapless playback ke saath sunna ek alag experience hai. Offline lyrics, smart playlists aur sleep timer bhi built-in hai.',
 E'Dark neon UI with themes\nReal-time 3D audio visualizer\n10-band equalizer with presets\nGapless playback & crossfade\nOffline lyrics sync\nSleep timer & gesture controls',
 'Music & Audio', '2.4.1', '18 MB', '/images/icons/neonbeat.png', 'https://example.com/files/neonbeat-2.4.1.apk', 12450, 4.8, 231, true, true),

('TaskFlow', 'taskflow',
 'Tasks, habits aur focus — sab ek jagah',
 'TaskFlow se apni productivity game strong karo. Tasks banao, habits track karo, Pomodoro focus sessions chalao — sab kuch ek beautiful, minimal interface mein. Smart reminders aapko kabhi bhoolne nahi denge.',
 E'Smart task lists with subtasks\nHabit tracker with streaks\nPomodoro focus timer\nCloud sync across devices\nWidgets & quick actions\nDark mode + AMOLED theme',
 'Productivity', '3.1.0', '9 MB', '/images/icons/taskflow.png', 'https://example.com/files/taskflow-3.1.0.apk', 8921, 4.6, 188, true, true),

('PixelForge', 'pixelforge',
 'Pixel art studio — draw anywhere',
 'PixelForge se retro pixel art banao jahan bhi ho. Layers, frames, palette tools aur onion-skin animation ke saath professional pixel art mobile par hi ban jayega. Export PNG/GIF ya spritesheet mein.',
 E'Layers with blend modes\nFrame-by-frame animation\nCustom & retro palettes\nOnion skin preview\nExport PNG, GIF, spritesheet\nPressure-sensitive stylus support',
 'Art & Design', '1.8.2', '22 MB', '/images/icons/pixelforge.png', 'https://example.com/files/pixelforge-1.8.2.apk', 6432, 4.9, 95, true, true),

('FitPulse', 'fitpulse',
 'AI workout coach jo aapke saath adapt karta hai',
 'FitPulse aapki fitness ko seriously leta hai — AI coach har workout ko aapke progress ke hisaab se adjust karta hai. Home ya gym, bodyweight ya weights — personalized plans har level ke liye.',
 E'AI-adaptive workout plans\nVideo guides with form tips\nProgress tracking + streaks\nCalorie & macro logger\nHome & gym modes\nOffline workout support',
 'Health & Fitness', '5.0.3', '31 MB', '/images/icons/fitpulse.png', 'https://example.com/files/fitpulse-5.0.3.apk', 15230, 4.7, 412, true, true),

('CodeSnap', 'codesnap',
 'Snippet manager for developers',
 'CodeSnap dev ka code companion — snippets save karo, tag karo, syntax highlight ke saath padho. 100+ languages support, instant search aur one-tap share. Kaam mein bahut aayega.',
 E'100+ language syntax highlighting\nInstant full-text search\nTags, folders & favorites\nOne-tap share as image\nGitHub Gist import/export\nFully offline — no account needed',
 'Developer Tools', '2.0.0', '7 MB', '/images/icons/codesnap.png', 'https://example.com/files/codesnap-2.0.0.apk', 4310, 4.5, 67, false, true),

('SkyCast', 'skycast',
 'Hyper-local weather with stunning radar',
 'SkyCast weather ko beautiful banata hai. Minute-by-minute rain alerts, interactive radar map aur 15-day forecast — sab kuch ek gorgeous interface mein jo weather ke mood ke saath badalta hai.',
 E'Minute-by-minute rain alerts\nInteractive weather radar\n15-day detailed forecast\nDynamic UI that matches weather\nSevere weather warnings\nHome screen widgets',
 'Weather', '4.2.7', '14 MB', '/images/icons/skycast.png', 'https://example.com/files/skycast-4.2.7.apk', 20114, 4.4, 523, false, true)
ON CONFLICT (slug) DO NOTHING;

-- Reviews
INSERT INTO reviews (app_id, author_name, rating, comment)
SELECT a.id, r.author, r.rating, r.comment
FROM apps a
JOIN (VALUES
  ('neonbeat', 'Aarav', 5, 'Visualizer dekh ke to maza aa gaya. Best music player I have used!'),
  ('neonbeat', 'Priya', 5, 'Equalizer presets are spot on. Dark theme gorgeous hai.'),
  ('neonbeat', 'Kabir', 4, 'Thoda heavy lagta hai old phones par, warna perfect.'),
  ('taskflow', 'Ishita', 5, 'Pomodoro + habit tracker combo ne meri discipline badal di.'),
  ('taskflow', 'Rohan', 4, 'Clean UI, sync fast hai. Widgets aur ache ho sakte hain.'),
  ('pixelforge', 'Meera', 5, 'Onion skin animation mobile par — unbelievable!'),
  ('fitpulse', 'Vikram', 5, 'AI coach ne gym membership save kar di. Ghar pe hi workout.'),
  ('fitpulse', 'Ananya', 4, 'Calorie tracker accurate hai. UI thoda aur light ho jaye.'),
  ('codesnap', 'Dev', 5, 'Ab mera poeta snippet library pocket mein hai.'),
  ('skycast', 'Neha', 4, 'Rain alerts bilkul accurate hain. Radar smooth chalta hai.')
) AS r(slug, author, rating, comment) ON r.slug = a.slug
WHERE NOT EXISTS (SELECT 1 FROM reviews WHERE app_id = a.id);
